# Arquitetura em Camadas (Layered Architecture)

## Descrição

A Arquitetura em Camadas é um padrão de design de software onde os componentes são organizados em camadas horizontais. Cada camada tem uma responsabilidade específica e só pode se comunicar com a camada adjacente abaixo dela. Este padrão promove a separação de responsabilidades e o baixo acoplamento.

## Fontes de Conhecimento

### Artigos e Documentação

*   [Pattern: Layered Architecture](https://microservices.io/patterns/layered-architecture.html) - Uma descrição do padrão no contexto de microsserviços.

## Aplicação no Projeto

A estrutura de pacotes da aplicação `entnotas-recebenotas` segue claramente uma Arquitetura em Camadas, típica de aplicações Spring Boot. O fluxo de uma requisição passa por estas camadas de forma ordenada:

1.  **Camada de Apresentação (Presentation Layer)**:
    *   **Pacote**: `br.com.itau.rs4.controllers`
    *   **Responsabilidade**: Expor os endpoints da API REST, receber as requisições HTTP, deserializar o corpo da requisição e invocar a camada de serviço.
    *   **Exemplo**: `NotasController` recebe o POST em `/v1/notas`.

2.  **Camada de Serviço (Service Layer)**:
    *   **Pacote**: `br.com.itau.rs4.services`
    *   **Responsabilidade**: Orquestrar a lógica de negócio principal da aplicação. Ela não contém a lógica de acesso a dados ou de exposição de API, mas coordena as chamadas para a camada de repositório.
    *   **Exemplo**: `NotasServiceImpl` contém o método `processaNota` que implementa o fluxo principal.

3.  **Camada de Acesso a Dados (Data Access Layer / Repository Layer)**:
    *   **Pacote**: `br.com.itau.rs4.repository`
    *   **Responsabilidade**: Encapsular a lógica de interação com as fontes de dados externas, como o S3 e o SQS.
    *   **Exemplo**: `S3RepositoryImpl` lida com o upload de arquivos para o S3, e `SqsServiceImpl` com o envio de mensagens para o SQS.

### Outros Pacotes de Suporte

*   **`domains`**: Contém os objetos que representam as entidades do negócio (ex: `Nota`) e os objetos de transferência de dados (DTOs).
*   **`handlers`**: Contém os manipuladores de exceções (`NotasExceptionHandler`), que interceptam erros e os traduzem em respostas HTTP apropriadas.
*   **`validation`**: Contém a lógica de validação customizada (`CanalOrigemValidator`).
*   **`config`**: Contém as classes de configuração do Spring (`MaskConfiguration`).
*   **`utils`**: Contém classes utilitárias com lógica reaproveitável (`ArquivoUtils`, `LogUtils`).

## 4. Alternativas e Evoluções

Embora a arquitetura em camadas tradicional seja eficaz e amplamente utilizada, arquiteturas mais modernas como a Hexagonal e a Clean Architecture oferecem vantagens em cenários de maior complexidade, focando em isolar ainda mais a lógica de negócio das dependências externas.

---

### 4.1. Arquitetura Hexagonal (Ports & Adapters)

A Arquitetura Hexagonal, também conhecida como "Ports and Adapters" (Portas e Adaptadores), inverte a dependência em relação à arquitetura em camadas tradicional. Em vez de a lógica de negócio depender da camada de dados, a camada de dados (e outras infraestruturas) depende da lógica de negócio.

#### Conceitos Principais

*   **Inside (Core/Hexágono)**: Contém a lógica de negócio pura e o estado do domínio. Não possui nenhuma dependência com tecnologia (frameworks, bancos de dados, etc.).
*   **Ports (Portas)**: São interfaces definidas pelo *Core* que definem como ele se comunica com o mundo exterior. Existem dois tipos:
    *   **Driving/Input Ports**: Definem como o mundo exterior pode invocar a lógica de negócio (ex: uma interface de serviço que será chamada por um Controller).
    *   **Driven/Output Ports**: Definem os serviços que o *Core* precisa do mundo exterior (ex: uma interface de repositório para persistir dados).
*   **Adapters (Adaptadores)**: São a implementação das portas. Eles traduzem a comunicação entre o *Core* e as tecnologias específicas.
    *   **Driving/Input Adapters**: Adaptadores que "dirigem" a aplicação (ex: um `RestController` que chama uma porta de entrada).
    *   **Driven/Output Adapters**: Adaptadores que são "dirigidos" pela aplicação (ex: uma implementação do repositório que usa JPA/JDBC, um cliente S3, um publicador de mensagens SQS).

![Arquitetura Hexagonal](https://i.imgur.com/y3A4f8H.png)

#### Vantagens

*   **Isolamento do Domínio**: A lógica de negócio é completamente independente de qualquer tecnologia externa, tornando-a mais fácil de entender e manter.
*   **Alta Testabilidade**: O *Core* pode ser testado em total isolamento, sem a necessidade de frameworks ou bancos de dados, resultando em testes unitários extremamente rápidos e confiáveis.
*   **Flexibilidade Tecnológica**: Trocar um banco de dados, um framework web ou um serviço de mensageria se resume a criar um novo adaptador, sem tocar na lógica de negócio.

#### Desvantagens

*   **Maior Complexidade Inicial**: Exige a criação de mais classes e interfaces (portas, adaptadores, mappers), o que pode ser um exagero para aplicações CRUD simples.
*   **Curva de Aprendizagem**: A equipe precisa entender bem os conceitos de inversão de dependência para aplicá-la corretamente.

#### Quando Usar?

*   Aplicações com lógica de negócio complexa e que é o principal ativo do projeto.
*   Projetos de longa duração, onde a troca de tecnologia é uma possibilidade real.
*   Quando a testabilidade máxima do domínio é um requisito crítico.

---

### 4.2. Clean Architecture

A Clean Architecture, proposta por Robert C. Martin (Uncle Bob), é uma evolução da Arquitetura Hexagonal, formalizando as camadas em círculos concêntricos e estabelecendo uma regra de dependência estrita.

#### Conceitos Principais

A arquitetura é dividida em quatro círculos principais:

1.  **Entities (Entidades)**: Contêm os objetos e as regras de negócio mais gerais da empresa. São os menos propensos a mudar quando algo externo muda.
2.  **Use Cases (Casos de Uso)**: Contêm as regras de negócio específicas da aplicação. Orquestram o fluxo de dados de e para as Entidades. É aqui que a lógica principal da aplicação reside.
3.  **Interface Adapters (Adaptadores de Interface)**: Convertem os dados do formato mais conveniente para os Use Cases e Entidades para o formato mais conveniente para as camadas externas (frameworks, banco de dados). Inclui Presenters, Controllers, Gateways.
4.  **Frameworks and Drivers (Frameworks e Drivers)**: A camada mais externa, composta por tecnologias como o banco de dados, o framework web (Spring), a UI, etc.

**A Regra da Dependência**: O código-fonte só pode ter dependências apontando para **dentro**. Nada em um círculo interno pode saber qualquer coisa sobre um círculo externo. Em particular, o nome de algo declarado em um círculo externo não deve ser mencionado por código em um círculo interno.

![Clean Architecture](https://blog.cleancoder.com/uncle-bob/images/2012-08-13-the-clean-architecture/CleanArchitecture.jpg)

#### Vantagens

*   **Independência Máxima**: Independente de framework, UI, banco de dados e qualquer agente externo.
*   **Testabilidade Extrema**: As regras de negócio podem ser testadas sem qualquer elemento externo, tornando os testes simples e rápidos.
*   **Clareza e Organização**: A separação estrita de responsabilidades torna o sistema mais fácil de entender e manter a longo prazo.

#### Desvantagens

*   **Alta Verbosidade e Complexidade**: É a que mais exige classes, interfaces e mapeamento de dados entre camadas (ex: `ApiDTO` -> `UseCaseInputModel` -> `Entity` -> `DatabaseModel`), o que pode ser extremamente custoso para projetos simples.
*   **Rigor Excessivo**: A aplicação estrita das regras pode levar a um excesso de engenharia se a complexidade do domínio não justificar.

#### Quando Usar?

*   Sistemas corporativos muito grandes, complexos e de longa duração, onde as regras de negócio são o ativo mais valioso e devem sobreviver a múltiplas gerações de tecnologia.
*   Projetos onde a falha não é uma opção e a testabilidade e a manutenibilidade são os requisitos mais importantes.

---

### Conclusão e Recomendações

| Característica     | Arquitetura em Camadas                     | Arquitetura Hexagonal                                  | Clean Architecture                         |
|:-------------------|:-------------------------------------------|:-------------------------------------------------------|:-------------------------------------------|
| **Foco Principal** | Organização técnica                        | Isolamento do domínio                                  | Independência do domínio                   |
| **Complexidade**   | Baixa                                      | Média                                                  | Alta                                       |
| **Testabilidade**  | Boa (com mocks)                            | Excelente                                              | Máxima                                     |
| **Flexibilidade**  | Média                                      | Alta                                                   | Máxima                                     |
| **Ideal para**     | Aplicações CRUD, projetos simples a médios | Aplicações com domínio rico, projetos de longa duração | Sistemas corporativos complexos e críticos |

Para o projeto **`entnotas-recebenotas`**, a **Arquitetura em Camadas tradicional é uma escolha pragmática e adequada**. A lógica de negócio é relativamente direta (receber, validar, salvar, notificar), e o Spring Boot já promove uma boa separação de responsabilidades. Migrar para uma Arquitetura Hexagonal poderia trazer benefícios de testabilidade, mas ao custo de uma complexidade adicional que talvez não se justifique para o escopo atual. A Clean Architecture seria um claro exagero.

A escolha da arquitetura é um trade-off. A chave é escolher o nível de complexidade que corresponde à complexidade do problema que está sendo resolvido.
