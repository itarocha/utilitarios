# Skill: Refactoring (Refatoração)

## 1. Descrição

Refatoração é o processo de reestruturar o código-fonte de um software **sem alterar seu comportamento externo**. O objetivo não é corrigir bugs ou adicionar novas funcionalidades, mas sim melhorar atributos não-funcionais do código, como:

*   **Legibilidade**: Tornar o código mais fácil de ser entendido por outros desenvolvedores (ou por você mesmo no futuro).
*   **Manutenibilidade**: Facilitar a correção de bugs e a adição de novas funcionalidades no futuro.
*   **Complexidade Reduzida**: Simplificar estruturas complexas e remover código desnecessário.
*   **Performance**: Em alguns casos, otimizar o desempenho.

Refatorar é como "limpar a cozinha enquanto você cozinha". É uma atividade contínua e disciplinada que mantém a base de código saudável e sustentável a longo prazo.

## 2. Fontes de Conhecimento

*   **Livro (Clássico)**: *Refactoring: Improving the Design of Existing Code* por Martin Fowler.
*   **Catálogo Online**: [Refactoring.guru](https://refactoring.guru/catalog) - Um catálogo completo de técnicas de refatoração e "code smells".

## 3. A Importância da Refatoração

*   **Facilita a Manutenção**: Um código limpo é mais fácil de entender, o que torna a correção de bugs e a adição de novas features uma tarefa mais rápida e segura.
*   **Melhora o Design do Software**: A refatoração contínua ajuda a evoluir o design do sistema de forma orgânica, evitando que ele se deteriore com o tempo.
*   **Encoraja o Entendimento do Código**: Ao refatorar, você é forçado a entender profundamente o que o código faz, muitas vezes encontrando bugs ou oportunidades de melhoria no processo.
*   **Aumenta a Produtividade**: Embora pareça um custo no curto prazo, a refatoração economiza tempo no futuro, pois a equipe gasta menos tempo tentando decifrar um código complexo e mais tempo entregando valor.

## 4. A Metodologia Segura de Refatoração

A regra de ouro da refatoração é **não quebrar nada**. Para garantir isso, é fundamental seguir um processo disciplinado e iterativo.

1.  **Garanta uma Rede de Segurança (Testes)**:
    *   Antes de tocar em qualquer linha de código, certifique-se de que existe uma suíte de testes unitários sólida e confiável cobrindo o comportamento da área que você vai refatorar.
    *   Se não houver testes, **escreva-os primeiro**. Refatorar sem testes é extremamente arriscado. Os testes são a sua garantia de que o comportamento externo não mudou.

2.  **Identifique o "Code Smell"**:
    *   Identifique um "mau cheiro" no código – um sintoma de que algo pode estar errado no design. (Veja a lista abaixo).

3.  **Faça uma Pequena Alteração**:
    *   Aplique **uma única e pequena** técnica de refatoração. Por exemplo, renomeie uma variável para um nome mais claro, ou extraia três linhas de código para um novo método. A chave é fazer mudanças atômicas.

4.  **Rode TODOS os Testes**:
    *   Após a pequena alteração, execute a suíte de testes completa. Se todos os testes passarem, você sabe que não quebrou nada. Se algum teste falhar, a mudança foi tão pequena que é fácil desfazê-la (Ctrl+Z) e tentar de outra forma.

5.  **Repita (ou Commit)**:
    *   Continue o ciclo: faça outra pequena alteração, rode os testes, e assim por diante. Se estiver usando controle de versão (como Git), faça commits frequentes a cada refatoração bem-sucedida.

Este ciclo `(Alterar -> Testar -> Repetir)` é o que torna a refatoração um processo seguro e eficaz, em vez de uma reescrita caótica e arriscada.

## 5. "Code Smells" e Técnicas de Refatoração

"Code Smells" são sinais de que o código pode ser melhorado. Abaixo estão alguns exemplos comuns e como eles podem ser (ou já foram) tratados no projeto.

| Code Smell                     | Descrição                                                             | Técnica de Refatoração                                             | Aplicação no Projeto                                                                                                                                                           |
|:-------------------------------|:----------------------------------------------------------------------|:-------------------------------------------------------------------|:-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| **Método Longo**               | Um método com muitas linhas e múltiplas responsabilidades.            | **Extrair Método**                                                 | A lógica de montar o path do arquivo S3 foi movida de `NotasServiceImpl` para `ArquivoUtils.montarPathArquivo`, tornando o serviço mais limpo e a lógica de path reutilizável. |
| **Código Duplicado**           | O mesmo bloco de código aparece em vários lugares.                    | **Extrair Método** ou **Criar Classe Utilitária**                  | Em vez de repetir a lógica de log em vários lugares, o projeto poderia centralizá-la em `LogUtils`, evitando duplicação.                                                       |
| **Classe Grande (God Class)**  | Uma classe que faz de tudo e tem muitas responsabilidades.            | **Extrair Classe** ou **Extrair Interface**                        | Se `NotasServiceImpl` começasse a lidar com regras complexas de validação, essas regras poderiam ser extraídas para uma nova classe `ValidadorDeNota`, seguindo o SRP.         |
| **Lista Longa de Parâmetros**  | Um método que recebe muitos parâmetros.                               | **Introduzir Objeto de Parâmetro** ou **Preservar Objeto Inteiro** | Em vez de passar `correlationId`, `canalOrigem`, `documentoSacado` separadamente, o projeto passa o objeto `Nota` inteiro, simplificando as assinaturas dos métodos.           |
| **Nomes Ruins**                | Variáveis, métodos ou classes com nomes que não revelam sua intenção. | **Renomear Variável/Método/Classe**                                | Uma variável `d` poderia ser renomeada para `documentoSacado`. Um método `process()` poderia ser renomeado para `processarNotaPendente()`.                                     |
| **Comentários Excessivos**     | Comentários usados para explicar um código complexo.                  | **Extrair Método** e **Renomear**                                  | Em vez de `// Calcula o juros e aplica o desconto`, extraia o bloco para um método `aplicarJurosEDesconto()`. O código deve se auto-explicar.                                  |
| **Código Morto (Dead Code)**   | Métodos, variáveis ou classes que não são mais usados.                | **Remover Código Morto**                                           | Simplesmente apagar o código não utilizado. Ferramentas de análise estática e a própria IDE ajudam a identificar isso.                                                         |
| **Uso de "Magic Numbers"**     | Números ou strings literais espalhados pelo código sem explicação.    | **Extrair Constante**                                              | Em vez de usar a string `"America/Sao_Paulo"` diretamente no código, ela é definida em `Constantes.TIMEZONE_SAO_PAULO`, dando-lhe um nome e um local centralizado.             |
| **Acoplamento com Biblioteca** | Código de negócio misturado com chamadas a uma biblioteca.            | **Encapsular Chamada de Biblioteca**                               | O uso de Lombok (`@Getter`, `@Builder`) substitui código boilerplate por anotações, e a criação de `S3Repository` esconde os detalhes do AWS SDK da camada de serviço.         |

