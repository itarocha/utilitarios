# Skill: JUnit 5

## 1. Descrição

JUnit 5 é o framework padrão de fato para a escrita e execução de testes unitários em Java. Ele é uma ferramenta essencial no ciclo de desenvolvimento para garantir a qualidade, a corretude e a robustez do código. Ao validar as menores unidades de lógica de forma isolada, o JUnit permite a detecção precoce de bugs, facilita a refatoração e serve como uma documentação viva do comportamento esperado do sistema.

Este projeto utiliza JUnit 5 (Jupiter) em conjunto com o Mockito para criar testes unitários eficazes para as camadas de serviço, controladores e outros componentes.

## 2. Fontes de Conhecimento

*   **Guia Oficial**: [JUnit 5 User Guide](https://junit.org/junit5/docs/current/user-guide/)
*   **Tutoriais**: [Baeldung: Introduction to JUnit 5](https://www.baeldung.com/junit-5)

## 3. Conceitos Fundamentais e Ciclo de Vida

O JUnit 5 executa os testes seguindo um ciclo de vida bem definido, controlado por anotações. Entender essa ordem é crucial para configurar e desmontar o estado dos testes corretamente.

*   `@BeforeAll` (equivalente ao `@BeforeClass` do JUnit 4): Executa um método estático **uma vez** antes de todos os testes da classe. Ideal para inicializar recursos caros e compartilhados (ex: iniciar um container de teste, conectar a um banco de dados em memória).
*   `@BeforeEach` (equivalente ao `@Before` do JUnit 4): Executa **antes de cada** método de teste (`@Test`). Perfeito para resetar o estado e garantir que cada teste rode de forma isolada (ex: recriar mocks, instanciar a classe sob teste).
*   `@Test`: Marca o método que contém a lógica de teste.
*   `@AfterEach` (equivalente ao `@After` do JUnit 4): Executa **depois de cada** método de teste. Usado para limpar recursos que foram criados no `@BeforeEach`.
*   `@AfterAll` (equivalente ao `@AfterClass` do JUnit 4): Executa um método estático **uma vez** depois de todos os testes da classe. Usado para liberar os recursos criados no `@BeforeAll`.

```
@BeforeAll -> uma vez
    @BeforeEach -> para o teste 1
    @Test (teste 1)
    @AfterEach -> para o teste 1

    @BeforeEach -> para o teste 2
    @Test (teste 2)
    @AfterEach -> para o teste 2
@AfterAll -> uma vez
```

## 4. Principais Anotações

*   `@Test`: Define um método como um caso de teste.
*   `@DisplayName("Um nome de teste descritivo")`: Permite usar frases legíveis (com espaços e caracteres especiais) como nomes de teste, melhorando a clareza dos relatórios.
*   `@Disabled`: Desabilita um método de teste ou uma classe inteira, com um motivo opcional. Útil para ignorar temporariamente testes quebrados ou irrelevantes.
*   `@Nested`: Permite criar classes de teste aninhadas, ajudando a organizar os testes por cenário ou método testado (BDD style).
*   `@Tag("fast")` / `@Tag("integration")`: Marca testes com "tags", permitindo filtrar e executar apenas certos grupos de testes.
*   `@Order(1)`: Quando usado com `@TestMethodOrder(MethodOrderer.OrderAnnotation.class)`, permite definir a ordem de execução dos testes. **Isso deve ser usado com cautela**, pois testes unitários devem ser independentes e não depender de ordem.

## 5. Assertions (Asserções)

Asserções são o coração de um teste; elas validam se o resultado de uma operação é o esperado.

*   **Ordem Correta**: A convenção do JUnit é `assertEquals(expected, actual)`.
    *   `expected`: O valor que você espera.
    *   `actual`: O valor que o seu código produziu.
    *   Seguir essa ordem é **crucial**, pois as mensagens de erro do JUnit são formatadas com base nela: `expected: <valor esperado> but was: <valor atual>`. Inverter a ordem gera mensagens confusas.

*   **Principais Asserções**:
    *   `assertEquals(expected, actual)`: Verifica se dois valores são iguais.
    *   `assertNotEquals(unexpected, actual)`: Verifica se são diferentes.
    *   `assertTrue(condition)` / `assertFalse(condition)`: Verifica uma condição booleana.
    *   `assertNotNull(object)` / `assertNull(object)`: Verifica se um objeto é nulo ou não.
    *   `assertSame(expected, actual)` / `assertNotSame(unexpected, actual)`: Verifica se duas variáveis apontam para o mesmo objeto na memória.
    *   `assertThrows(ExpectedException.class, () -> { ... })`: Verifica se o bloco de código lança a exceção esperada. É a forma moderna e preferida de testar exceções.
    *   `assertAll(() -> assertion1, () -> assertion2)`: Agrupa múltiplas asserções. Todas serão executadas, e as falhas de todas serão reportadas juntas, em vez de o teste parar na primeira falha.

## 6. Boas Práticas

1.  **Testes devem ser independentes**: A execução de um teste não deve afetar o resultado de outro. Use `@BeforeEach` para garantir um estado limpo.
2.  **Teste um cenário por método**: Mantenha os métodos de teste focados em um único comportamento ou condição.
3.  **Use `@DisplayName`**: Nomes de teste claros e descritivos são uma forma de documentação.
4.  **Siga o padrão AAA (Arrange, Act, Assert)**:
    *   **Arrange (Arranjar)**: Configure o cenário do teste (crie objetos, defina o comportamento dos mocks).
    *   **Act (Agir)**: Execute o método que você está testando.
    *   **Assert (Verificar)**: Use asserções para verificar se o resultado foi o esperado.
5.  **Prefira `assertThrows` a `try-catch`**: É mais limpo e expressivo para testar exceções.
6.  **Mantenha os testes rápidos**: Testes unitários devem rodar em milissegundos. Operações lentas (I/O, rede) devem ser mockadas.

## 7. Exemplo de Código Completo

Este exemplo testa a classe `NotasServiceImpl`, seguindo as boas práticas.

```java
import br.com.itau.rs4.services.NotasServiceImpl;
import br.com.itau.rs4.repository.S3Repository;
import br.com.itau.rs4.services.sqs.SqsService;
import br.com.itau.rs4.domains.entrada.Nota;
import br.com.itau.rs4.exceptions.S3UploadException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class) // Integra JUnit 5 com Mockito
@DisplayName("Testes para NotasServiceImpl")
class NotasServiceImplTest {

    // Mocks para as dependências externas do serviço
    @Mock
    private S3Repository s3Repository;
    @Mock
    private SqsService sqsService;

    // Injeta os mocks acima na instância de NotasServiceImpl
    @InjectMocks
    private NotasServiceImpl notasService;

    private Nota notaValida;

    @BeforeEach
    void setUp() {
        // Arrange: Cria um objeto Nota válido para ser usado nos testes
        // Isso garante um estado limpo e consistente para cada teste
        notaValida = new Nota(); // Supondo que Nota tenha um construtor e setters
        notaValida.setCorrelationId("test-corr-id");
        // ... preencher outros campos necessários
    }

    @Nested
    @DisplayName("Cenários de Sucesso")
    class Sucesso {
        @Test
        @DisplayName("Deve processar a nota, fazer upload no S3 e enviar para SQS com sucesso")
        void processaNota_ComNotaValida_DeveExecutarComSucesso() {
            // Arrange (Opcional, mocks já configurados para não lançar exceção)
            // Nenhuma configuração adicional de mock é necessária para o caminho feliz

            // Act
            // Executa o método a ser testado
            assertDoesNotThrow(() -> notasService.processaNota(notaValida));

            // Assert
            // Verifica se os métodos corretos dos mocks foram chamados
            try {
                verify(s3Repository, times(1)).uploadJson(anyString(), anyString(), any());
                verify(sqsService, times(1)).publicarMensagem(any(), anyString(), anyString());
            } catch (Exception e) {
                fail("Uma exceção não deveria ter sido lançada durante a verificação dos mocks.");
            }
        }
    }

    @Nested
    @DisplayName("Cenários de Falha")
    class Falha {
        @Test
        @DisplayName("Deve lançar S3UploadException quando o upload no S3 falhar")
        void processaNota_QuandoS3Falha_DeveLancarS3UploadException() throws S3UploadException {
            // Arrange
            // Configura o mock do S3 para lançar uma exceção quando chamado
            doThrow(new S3UploadException("Erro no S3")).when(s3Repository).uploadJson(anyString(), anyString(), any());

            // Act & Assert
            // Verifica se a chamada ao método lança a exceção esperada
            S3UploadException exception = assertThrows(S3UploadException.class, () -> {
                notasService.processaNota(notaValida);
            });

            // Assert (Opcional): Verifica a mensagem da exceção
            assertEquals("Erro no S3", exception.getMessage());

            // Verifica que o método de publicar no SQS nunca foi chamado, pois o fluxo foi interrompido
            verify(sqsService, never()).publicarMensagem(any(), anyString(), anyString());
        }
    }
}
```
