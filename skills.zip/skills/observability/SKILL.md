# Observabilidade (Datadog)

## Descrição

Padrões de instrumentação da aplicação no Datadog: logs estruturados, spans customizados (APM) e métricas custom (DogStatsD). Consulte este documento sempre que for criar, alterar ou revisar instrumentação, nomes de métricas, tags ou spans.

## Fontes de Conhecimento

### Artigos e Documentação

*   [Datadog APM - Java Tracer](https://docs.datadoghq.com/tracing/trace_collection/automatic_instrumentation/dd_libraries/java/) - Configuração do `dd-java-agent` e da anotação `@Trace`.
*   [Datadog - Custom Metrics via DogStatsD](https://docs.datadoghq.com/developers/dogstatsd/) - Envio de métricas custom para o agent.
*   [java-dogstatsd-client](https://github.com/DataDog/java-dogstatsd-client) - Cliente oficial usado no projeto.
*   [Datadog - Metric Naming Conventions](https://docs.datadoghq.com/developers/guide/what-best-practices-are-recommended-for-naming-metrics-and-tags/) - Boas práticas de nomenclatura de métricas e tags.

## Aplicação no Projeto

### 1. Arquitetura

O agent Datadog roda como **sidecar** da task ECS (bloco `task_datadog` em `infra/terraform/main.tf`). A aplicação se comunica com ele por:

*   **APM**: `dd-java-agent.jar` carregado via `-javaagent` em `app/entrypoint.sh` (baixado no `Dockerfile`).
*   **DogStatsD**: UDP em `localhost:8125` (endereço fixo no código; o agent é sidecar da task, rede `awsvpc`).
*   **Logs**: correlacionados ao trace via `DD_LOGS_INJECTION=true`.

### 2. Métricas custom

Código em `app/src/main/java/br/com/itau/rs4/observability/`:

| Classe                                    | Responsabilidade                                                  |
|-------------------------------------------|-------------------------------------------------------------------|
| `MetricasService` / `MetricasServiceImpl` | API de publicação de métricas (sucesso, erro, duração, por canal) |
| `MetricasConstantes`                      | Prefixo, nomes de fluxo/ação, chaves de tag e nomes de span       |
| `MetricasTags`                            | Normalização de valores e montagem de tags                        |
| `DogStatsDConfiguration`                  | Bean `StatsDClient` (`NonBlockingStatsDClientBuilder`, destino fixo `localhost:8125`) |

**Padrão de nomenclatura obrigatório**:

```
custom.RS4.dogstatsd.app.entnotas_recebenotas.{nome_fluxo}.{acao}.{sucesso|erro}
```

O prefixo é aplicado pelo próprio `StatsDClient`; o código informa apenas `{nome_fluxo}.{acao}.{resultado}`.

**Métricas existentes** — todas com as três variações `.sucesso`, `.erro` e `.duracao`, e todas com a tag `canal_origem`, permitindo medir cada etapa de forma independente:

| Fluxo                | Ação         | Onde é instrumentado                                    | Porta de entrada |
|----------------------|--------------|---------------------------------------------------------|------------------|
| `controller`         | `recebe`     | `NotasController` + `NotasExceptionHandler` (erros 4xx)  | HTTP             |
| `consumo_sqs`        | `consome`    | `NotasServiceImpl.consumirMensagemSqs`                   | SQS              |
| `processamento_nota` | `processa`   | `NotasServiceImpl.processaNota`                           | HTTP e SQS       |
| `s3`                 | `upload`     | `S3RepositoryImpl`                                        | HTTP e SQS       |
| `sqs`                | `publicacao` | `SqsServiceImpl`                                          | HTTP e SQS       |

**Como separar as portas de entrada**: `processamento_nota`, `s3` e `sqs` são compartilhados pelos dois fluxos de entrada. Para medir volume, erro e latência *por porta de entrada* use `controller.recebe.*` (API) e `consumo_sqs.consome.*` (SQS).

**Erros 4xx**: `MethodArgumentNotValidException`, `ConstraintViolationException` e `HttpMessageNotReadableException` acontecem **antes** do método do controller, por isso são contabilizados em `controller.recebe.erro` pelo `NotasExceptionHandler`, com a tag `http_status` além das dimensões de entrada. Nos erros de **validação** o payload já foi vinculado pelo Spring, então a nota é recuperada de `BindingResult.getTarget()` (ou de `ConstraintViolation.getRootBean()`) e as dimensões saem preenchidas; em `HttpMessageNotReadableException` o JSON nem chegou a ser desserializado e as três dimensões caem em `nao_informado`. Os demais handlers **não** publicam métrica: aquelas exceções já foram contabilizadas no controller ou no service, e contabilizá-las de novo geraria contagem duplicada.

### 2.2. Dimensões extras nas métricas de erro das portas de entrada

As métricas de **erro** de `controller.recebe` e `consumo_sqs.consome` levam, além de `canal_origem`, as tags `documento_sacado` e `quantidade_titulos`, montadas por `MetricasTags.tagsErroEntrada(...)`. Motivos:

*   `canal_origem` sozinho não permite **contar ocorrências únicas**: o SQS reentrega a mesma mensagem (retries até a DLQ), e sem uma dimensão por nota um único erro apareceria como vários no dashboard. Com `documento_sacado` é possível contar únicos (`count_nonzero`) filtrando por `canal_origem`.
*   Sem essas dimensões, um erro 400 não permite identificar qual nota falhou, o que inviabiliza o debug.

Regras específicas:

*   **Somente nas métricas de erro.** `sucesso` e `duracao` continuam apenas com `canal_origem`, mantendo baixa a cardinalidade das métricas de volume. Isso é uma **exceção consciente à regra 7** (simetria de tags): no dashboard, agrupe volume por `canal_origem` e trate a métrica de erro como a visão detalhada.
*   **Exceção consciente à regra 5** (cardinalidade): o volume de erro nessas duas portas é baixo — não são endpoints expostos a frontend, já existem validações a montante — então o custo adicional de timeseries é aceitável. **Não replique esse padrão** em métricas de sucesso, duração ou em fluxos de alto volume.
*   `numero_titulo` foi deliberadamente **descartado**: uma nota tem N títulos, logo não existe valor único; a dimensão útil é a quantidade.
*   Quando a desserialização para `Nota` falha (payload malformado, enum inválido), as dimensões são extraídas do **JSON bruto** por `MetricasTags.tagsErroEntradaDoJson(payload)` (aceita `snake_case` e `camelCase`). O `canal_origem` da métrica de duração vem de `MetricasTags.canalOrigemDoJson(payload)` pelo mesmo motivo. Cada campo cai em `nao_informado` de forma independente.

**Propagação do `canal_origem`**: `S3Repository.uploadArquivoJsonS3` e `SqsService.publicaMensagemSQS` recebem o canal de origem exclusivamente para uso como tag, permitindo cruzar falhas de infraestrutura por canal.

**Contagem por canal de origem** (SISPAG, INVERTIDO, ARQUIVOS, API, ...): usa-se **apenas a métrica genérica** do fluxo (`...processamento_nota.processa.sucesso|erro`) com a tag `canal_origem:{canal}`, permitindo `group by` no Datadog.

> Não crie métricas dedicadas por canal (ex.: `...sispag.processamento.sucesso`). O nome da métrica não deve conter valores dinâmicos — a diferenciação por canal vive exclusivamente na tag `canal_origem`.

**Tags**: `canal_origem`, `origem` (`api`/`sqs`), `tipo_erro` (nome simples da exceção, normalizado), `http_status` (apenas no fluxo `controller`), `documento_sacado` e `quantidade_titulos` (apenas nas métricas de **erro** das portas de entrada, ver 2.2), além de `service` e `env` como tags constantes.

**Duração** é publicada como `distribution` (`recordDistributionValue`), em milissegundos. Use sempre `registrarDuracaoDesde(fluxo, acao, inicioNano, tags)` no bloco `finally`: a conversão de nanossegundos para milissegundos pertence à camada de métricas e não deve ser repetida nas classes de negócio.

### 2.1. Telemetria à prova de falhas

Nenhuma etapa da telemetria pode quebrar o fluxo de negócio. A blindagem fica **dentro da camada de métricas**, e não espalhada em `try/catch` nos pontos de chamada (o que poluiria as classes de negócio):

*   `MetricasServiceImpl.executarComSeguranca` envolve a publicação **e** a montagem do nome da métrica e das tags (`nomeMetrica`, `comTagTipoErro`). Nada é calculado fora do bloco protegido — é aqui que mora o único risco real (cliente StatsD e manipulação do array de tags).
*   Falhas são logadas em `WARN` e descartadas.
*   `MetricasTags` é seguro **por construção**, não por `try/catch`: os casos de falha possíveis (valor nulo, vazio ou sem nenhum caractere válido, ex.: `"---"`) retornam o fallback `nao_informado`, e as demais operações são manipulações de `String` com regex constante, que não lançam exceção.

> Não adicione `try/catch` em código que comprovadamente não pode lançar exceção. Além de ser código morto, o bloco é intestável e derruba a cobertura exigida pelo Sonar (mínimo de 95%). Proteja onde a falha é real; garanta o resto por construção.

### 3. Spans customizados (APM)

Criados com `@Trace` (`com.datadoghq:dd-trace-api`), com `operationName` e `resourceName` definidos em `MetricasConstantes`:

| Método                                 | operationName                    |
|----------------------------------------|----------------------------------|
| `NotasServiceImpl.processaNota`        | `recebenotas.processamento_nota` |
| `NotasServiceImpl.consumirMensagemSqs` | `recebenotas.consumo_sqs`        |
| `S3RepositoryImpl.uploadArquivoJsonS3` | `recebenotas.s3.upload`          |
| `SqsServiceImpl.publicaMensagemSQS`    | `recebenotas.sqs.publicacao`     |

**Limitação conhecida**: o `dd-trace-api` não expõe API pública para obter o span ativo e adicionar tags customizadas. Por isso as dimensões de negócio (`canal_origem`, `tipo_erro`) vivem nas métricas e nos logs estruturados, não como tags de span. Para tags de span seria necessário adicionar `io.opentelemetry:opentelemetry-api` e habilitar `DD_TRACE_OTEL_ENABLED=true`.

### 4. Configuração

**Lado da aplicação**: o destino do DogStatsD é fixo, em `Constantes.HOST_VALUE` (`localhost`) e `Constantes.PORT_NUMBER` (`8125`), sem properties nem flag de habilitação. Essa é uma **decisão consciente e alinhada aos demais ECS da squad**: o agent é sempre sidecar da própria task (rede `awsvpc`), portanto o endereço não varia entre ambientes. Não reintroduza configuração externa para host/porta sem alinhar com o time.

Implicações a ter em mente:

*   Rodando localmente (sem agent), o cliente é criado normalmente e envia pacotes UDP para `localhost:8125`. Como UDP não exige destinatário e o `NonBlockingStatsDClient` não bloqueia, isso não afeta a aplicação.
*   Testes que sobem o contexto Spring instanciam o bean real do `StatsDClient`. Em testes unitários, use `@Mock MetricasService` em vez de depender do bean.

**Lado da infraestrutura** (`infra/terraform/locals.tf`, em `task_environment_vars`, propagadas também ao container do agent):

| Variável                                                                             | Finalidade                                                    |
|--------------------------------------------------------------------------------------|---------------------------------------------------------------|
| `DD_USE_DOGSTATSD`                                                                   | Habilita a coleta DogStatsD no agent                          |
| `DD_DOGSTATSD_NON_LOCAL_TRAFFIC`                                                     | Permite ao agent receber pacotes de outros containers da task |
| `DD_TRACE_ENABLED`                                                                   | Habilita o tracer                                             |
| `DD_TRACE_ANNOTATIONS_ENABLED`                                                       | Habilita a instrumentação das anotações `@Trace`              |
| `DD_TRACE_CLOUD_REQUEST_PAYLOAD_TAGGING` / `DD_TRACE_CLOUD_RESPONSE_PAYLOAD_TAGGING` | Captura payloads das chamadas AWS nos spans                   |
| `DD_ENV`, `DD_SERVICE`, `DD_VERSION`, `DD_LOGS_INJECTION`, `DD_TAGS`                 | Identificação do serviço e correlação de logs                 |

## Regras ao Instrumentar Novos Fluxos

1.  **Nunca quebre o negócio por causa de telemetria**: toda etapa de emissão de métrica — publicação, montagem do nome e montagem das tags — deve estar protegida. Faça isso reutilizando `MetricasServiceImpl.executarComSeguranca` e `MetricasTags`, **não** adicionando `try/catch` em cada ponto de chamada.
2.  **Não crie strings soltas**: nomes de fluxo, ação, span e chaves de tag devem ser constantes em `MetricasConstantes`.
3.  **Respeite o padrão** `{nome_fluxo}.{acao}.{sucesso|erro}` — não invente sufixos fora de `sucesso`, `erro` e `duracao`.
4.  **Nomes de métrica são estáticos**: nunca componha o nome com valores de negócio (canal de origem, formato, etc.). Dimensões dinâmicas devem ser tags.
5.  **Evite alta cardinalidade em tags**: nunca use `correlation_id` ou path do S3 como tag. Esses dados pertencem aos logs estruturados e ao span. A única exceção é `documento_sacado` nas métricas de **erro** das portas de entrada (ver 2.2), justificada pelo baixo volume de erros e pela necessidade de contar ocorrências únicas.
6.  **Normalize valores dinâmicos** com `MetricasTags.normalizar` antes de compor nomes ou tags.
7.  **Registre sucesso, erro e duração**: o `duracao` sempre no bloco `finally` (via `registrarDuracaoDesde`), para cobrir os dois caminhos. Erro e duração devem sair com **as mesmas tags** do sucesso, para não quebrar o `group by` no dashboard — quando a dimensão ainda não é conhecida (ex.: payload SQS não desserializado), tente extraí-la do JSON bruto e, em último caso, use o fallback `nao_informado`. A única exceção são as dimensões extras das métricas de erro das portas de entrada (ver 2.2).
8.  **Não conte o mesmo evento duas vezes**: antes de instrumentar um novo ponto, verifique se a exceção já é contabilizada em outra camada.
9.  **Testes**: injete `MetricasService` como `@Mock` nos testes de serviços/repositórios e verifique o nome exato da métrica nos testes de `MetricasServiceImpl`. Atenção: métodos `default` da interface (`registrarDuracaoDesde`) **não** delegam para os métodos concretos quando a interface é mockada — verifique diretamente a chamada ao método `default`.
10. **Fluxo SQS**: erros do `@SqsListener` não passam pelo `NotasExceptionHandler` (`@RestControllerAdvice` cobre apenas o fluxo HTTP). A exceção é propagada de propósito, para não fazer o *ack* da mensagem e permitir retry/DLQ.
