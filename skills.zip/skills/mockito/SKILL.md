# Skill: Mockito

## 1. Descrição

Mockito é um framework de *mocking* para Java, essencial para a escrita de testes unitários eficazes. Sua função é criar objetos "dublês" (test doubles) de dependências de uma classe, permitindo que a classe sob teste seja completamente isolada. Isso garante que o teste unitário valide apenas a lógica daquela unidade específica, sem ser afetado pelo comportamento ou estado de suas dependências (como bancos de dados, APIs externas ou outras classes de serviço).

## 2. Fontes de Conhecimento

*   **Documentação Javadoc**: [Mockito API](https://javadoc.io/doc/org.mockito/mockito-core/latest/org/mockito/Mockito.html) (referência principal)
*   **Guias**: [Baeldung: Introduction to Mockito](https://www.baeldung.com/mockito-series)

## 3. Como o Mockito Funciona?

Mockito cria "mocks" em tempo de execução usando bibliotecas de geração de bytecode (como Byte Buddy). Um mock é, na essência, um **objeto proxy** que se parece exatamente com a classe ou interface original (possui os mesmos métodos), mas não tem nenhuma lógica de negócio real. Por padrão, todos os seus métodos não fazem nada e retornam um valor "vazio" (0, `false`, `null` ou coleções vazias).

O poder do Mockito reside na capacidade de:
1.  **Stubbing**: Instruir esses métodos a se comportarem de uma maneira específica quando chamados (`when... thenReturn`).
2.  **Verification**: Verificar se os métodos do mock foram chamados durante o teste (`verify`).

## 4. Formas de Criar Test Doubles

Mockito oferece principalmente duas formas de criar dublês de teste:

*   `@Mock`: Cria um dublê completamente "oco". Toda a lógica original da classe é substituída. Você **deve** definir o comportamento (stub) para cada método que será chamado no teste. É a forma mais comum e recomendada para testes unitários, pois garante o isolamento total.

*   `@Spy`: Cria um "espião" do objeto real. Um spy envolve uma instância real da classe, mantendo toda a sua lógica original. Por padrão, chamar um método em um spy executará o método real. Você pode, seletivamente, fazer o stub de alguns métodos enquanto deixa os outros executarem sua lógica original.
    *   **Quando usar?** Com muito cuidado. É útil para testar classes legadas difíceis de refatorar ou quando você quer testar a maior parte de uma classe, mas precisa "curto-circuitar" apenas um método específico (ex: um que faz uma chamada de rede).
    *   **Atenção**: Ao fazer stub de spies, use a sintaxe `doReturn(...).when(spy).method()`. Usar `when(spy.method()).thenReturn(...)` pode invocar o método real, causando efeitos colaterais.

## 5. Principais Funcionalidades e Casos de Uso

### 5.1. Criação e Injeção de Mocks

*   `@Mock`: Anotação para declarar um campo que deve ser um mock.
*   `@InjectMocks`: Anotação para criar uma instância da classe sob teste e **injetar** os campos anotados com `@Mock` (ou `@Spy`) nela. Mockito tentará a injeção por construtor, por setter ou por reflection.

### 5.2. Stubbing (Definindo o Comportamento)

O stubbing é como programamos o mock para responder às chamadas durante o teste.

#### Para métodos que retornam um valor:

```java
// Sintaxe padrão: when(chamada).thenReturn(resultado)
when(s3Repository.uploadJson(anyString(), anyString(), any())).thenReturn("caminho/para/o/arquivo.json");

// Stub para lançar uma exceção
when(s3Repository.uploadJson(any(), any(), any())).thenThrow(new S3UploadException("Falha no upload"));
```

#### Para métodos `void`:

Como métodos `void` não retornam valor, a sintaxe `when` não se aplica. Usamos a família `do...when`.

```java
// Não fazer nada (comportamento padrão, mas útil para clareza)
doNothing().when(sqsService).publicarMensagem(any(), anyString(), anyString());

// Lançar uma exceção
doThrow(new SQSEnvioException("Falha ao enviar")).when(sqsService).publicarMensagem(any(), any(), any());

// Executar uma lógica customizada
doAnswer(invocation -> {
    InformacoesArquivo info = invocation.getArgument(0);
    System.out.println("Mensagem publicada para o bucket: " + info.getBucket());
    return null; // Sempre retorne null para métodos void
}).when(sqsService).publicarMensagem(any(), any(), any());
```

### 5.3. Verificação de Comportamento (Verification)

Após a fase "Act" do teste, usamos `verify` para checar se a classe sob teste interagiu corretamente com suas dependências.

```java
// Verifica se o método foi chamado exatamente 1 vez (padrão)
verify(s3Repository, times(1)).uploadJson(anyString(), anyString(), any());

// Verifica se o método nunca foi chamado
verify(sqsService, never()).publicarMensagem(any(), any(), any());

// Verifica se foi chamado pelo menos 2 vezes
verify(s3Repository, atLeast(2)).uploadJson(any(), any(), any());

// Verifica a ordem das chamadas
InOrder inOrder = inOrder(s3Repository, sqsService);
inOrder.verify(s3Repository).uploadJson(any(), any(), any()); // Verifica que o upload no S3 veio antes
inOrder.verify(sqsService).publicarMensagem(any(), any(), any()); // da publicação no SQS
```

### 5.4. Matchers de Argumento

Matchers (`any()`, `eq()`, etc.) são usados no stubbing e na verificação para dar flexibilidade.

*   `any()`: Corresponde a qualquer objeto daquele tipo (não nulo).
*   `anyString()`, `anyInt()`: Corresponde a qualquer valor do tipo específico.
*   `eq("valor-especifico")`: Usado quando você precisa misturar um valor específico com outros matchers. **Regra**: Se você usa um matcher em uma chamada de método, **todos** os argumentos devem ser matchers.
*   `argThat(argument -> argument.getBucket().equals("meu-bucket"))`: Para validações complexas.

### 5.5. Capturando Argumentos com `ArgumentCaptor`

Quando você precisa verificar o valor exato que foi passado para um método de um mock.

```java
// 1. Crie o captor
ArgumentCaptor<InformacoesArquivo> infoCaptor = ArgumentCaptor.forClass(InformacoesArquivo.class);

// 2. Use-o na verificação
verify(sqsService).publicarMensagem(infoCaptor.capture(), anyString(), anyString());

// 3. Pegue o valor e faça asserções sobre ele
InformacoesArquivo capturedInfo = infoCaptor.getValue();
assertEquals("meu-bucket-esperado", capturedInfo.getBucket());
```

## 6. Integração com JUnit 5: `@ExtendWith`

A anotação `@ExtendWith(MockitoExtension.class)` no topo da classe de teste é o que "liga" o Mockito ao ciclo de vida do JUnit 5. A `MockitoExtension` faz o seguinte:
1.  **Antes de cada teste (`@BeforeEach`)**: Ela inicializa todos os campos anotados com `@Mock`, `@Spy` e `@InjectMocks`. Isso elimina a necessidade de chamar `MockitoAnnotations.openMocks(this)` manualmente.
2.  **Validação**: Após cada teste, ela verifica se não há stubs não utilizados, ajudando a manter os testes limpos.

## 7. Limitações do Mockito

Mockito não pode mockar:
*   Métodos estáticos (requer a dependência `mockito-inline`).
*   Métodos `final`.
*   Métodos `private` (isso é intencional, pois você não deveria testar métodos privados diretamente).
*   Classes `final`.
*   A criação de objetos com `new` (requer PowerMock, que geralmente é um sinal de código mal projetado).

## 8. Exemplo de Aplicação no Projeto

```java
@ExtendWith(MockitoExtension.class)
@DisplayName("Testes para NotasServiceImpl")
class NotasServiceImplTest {

    @Mock
    private S3Repository s3Repository;
    @Mock
    private SqsService sqsService;

    @InjectMocks
    private NotasServiceImpl notasService;

    @Test
    @DisplayName("Deve lançar exceção e não enviar para SQS se upload no S3 falhar")
    void processaNota_QuandoS3Falha_DeveLancarExcecaoENaoChamarSqs() throws S3UploadException {
        // Arrange (Stubbing)
        Nota nota = new Nota(); // Preencher nota
        // Configura o mock do S3 para lançar uma exceção quando o método for chamado
        doThrow(new S3UploadException("Erro de acesso ao S3")).when(s3Repository).uploadJson(anyString(), anyString(), any());

        // Act & Assert
        // Verifica se a chamada ao serviço lança a exceção esperada
        assertThrows(ProcessamentoNotaException.class, () -> {
            notasService.processaNota(nota);
        });

        // Assert (Verification)
        // Verifica que o S3 foi chamado, mas o SQS nunca foi, pois o fluxo parou antes.
        verify(s3Repository, times(1)).uploadJson(anyString(), anyString(), any());
        verify(sqsService, never()).publicarMensagem(any(), anyString(), anyString());
    }
}
```
