# Test-Driven Development (TDD)

## Descrição

TDD é uma prática de desenvolvimento de software que inverte o processo de desenvolvimento tradicional. Em vez de escrever o código da funcionalidade primeiro e os testes depois, o TDD segue um ciclo curto e repetitivo:
1.  **Red**: Escrever um teste automatizado que falha.
2.  **Green**: Escrever o mínimo de código necessário para fazer o teste passar.
3.  **Refactor**: Melhorar o código escrito sem alterar seu comportamento.

## Fontes de Conhecimento

### Artigos e Documentação

*   [What is Test Driven Development (TDD)?](https://www.browserstack.com/guide/what-is-test-driven-development) - Um guia completo que explica o conceito, o ciclo e os benefícios do TDD.

## Aplicação no Projeto

O TDD é uma disciplina que se aplica ao processo de desenvolvimento, e sua evidência no código-fonte está na alta cobertura de testes e na qualidade dos testes unitários.

*   **Estrutura de Testes**: O projeto possui uma estrutura clara para testes unitários em `app/src/test/java/`.
*   **Foco em Unidades**: Testes como `NotasControllerTest`, `NotasServiceImplTest` e `S3RepositoryImplTest` focam em testar uma única unidade de código (uma classe), utilizando mocks (via Mockito) para isolar dependências externas como S3 e SQS.
*   **Ciclo TDD Sugerido**:
    1.  Ao criar uma nova validação, como um novo `CanalOrigem`, o desenvolvedor primeiro escreveria um teste em `CanalOrigemValidatorTest` que usa esse novo canal e espera que a validação passe. O teste falharia inicialmente.
    2.  Em seguida, o desenvolvedor adicionaria o novo canal à lista de canais permitidos para fazer o teste passar.
    3.  Finalmente, o código seria refatorado se necessário.
*   **Cobertura de Código**: A configuração do JaCoCo no `pom.xml` para gerar relatórios de cobertura de testes é um indicativo da importância dos testes no projeto, o que é um pilar do TDD.

## Regras de Implementação de Testes

1.  **Nomenclatura com BDD**: Utilize sempre a anotação `@DisplayName` do JUnit para descrever o comportamento esperado do teste, seguindo o padrão BDD (Behavior-Driven Development) em português. Ex: `@DisplayName("Dado um payload válido, Quando processar a nota, Então deve salvar no S3 e publicar no SQS")`.

2.  **Mocks Realistas e Completos**: Ao criar mocks de objetos de entrada (payloads, DTOs), sempre popule **todos** os campos do objeto, mesmo que não sejam diretamente usados no teste. Isso garante que o mock seja o mais próximo possível de um cenário real e evita que testes quebrem no futuro caso o objeto passe a usar um campo antes nulo.

3.  **Cobertura de 100%**: Para todas as classes e métodos criados ou alterados, os testes unitários devem atingir 100% de cobertura de linhas, branches e métodos. Todos os cenários de sucesso e de falha devem ser testados.

4.  **Teste de Todos os Blocos `catch`**: Em cenários com múltiplos blocos `catch` para exceções distintas, cada bloco deve ser explicitamente testado. Simule a exceção específica de cada `catch` e valide se o tratamento de erro correspondente é executado.

5.  **Asserts para Testes de Mutação**: As asserções devem ser robustas para sobreviver a testes de mutação. Em vez de apenas verificar se um método foi chamado (`verify(mock, times(1)).doSomething()`), valide o **estado** do objeto retornado, os **argumentos** capturados em um `ArgumentCaptor`, ou o **resultado** de uma interação. Isso garante que o teste está validando o comportamento correto, e não apenas a execução de um método.

6.  **Teste de Mecanismos de Retry**: Para métodos anotados com `@Retryable`, crie testes que validem o comportamento de retentativa. É obrigatório testar cenários que simulem 1, 2 ou mais falhas (lançando a exceção esperada) antes de um retorno com sucesso, verificando o número de chamadas ao método.

7.  **Teste de Mecanismos de Cache**: Onde houver anotações de cache (`@Cacheable`, `@CachePut`, etc.), os testes devem validar o comportamento do cache. Crie cenários para verificar se, em uma segunda chamada com os mesmos parâmetros, o método real não é executado e o resultado é retornado do cache.

8.  **Frameworks Padrão**: Utilize sempre JUnit 5 como o framework de testes e Mockito para a criação de mocks, mantendo o padrão do projeto. Os mocks devem ser usados para isolar a unidade sob teste, focando apenas no essencial para o cenário testado.

