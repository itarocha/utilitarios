# Convenções Específicas do Projeto

## Descrição

Esta seção documenta as convenções de codificação, nomenclatura e padrões específicos que foram adotados para este projeto, a fim de manter a consistência e a qualidade do código.

## Fontes de Conhecimento

### Documentos Internos

*   [AGENTS.md](../../../AGENTS.md) - O guia de contexto principal do projeto, que serve como a fonte da verdade para a maioria das convenções.

## Aplicação no Projeto

*   **Nomenclatura de Branches**: As branches de feature devem seguir o padrão `feature/HIS-...`, conforme definido no `AGENTS.md`.
*   **Mensagens de Commit**: Os commits devem seguir o padrão de mensagens convencionais em português (`feat:`, `fix:`, `refactor:`, etc.).
*   **Mapeamento JSON**: As entidades de entrada (`Nota`) devem usar `@JsonAlias` para aceitar tanto `camelCase` quanto `snake_case`, enquanto os DTOs de saída para o S3 (`NotaDto`) devem ser serializados em `snake_case`.
*   **Tratamento de Nulos**: Para evitar `NullPointerException`, os getters em objetos de domínio devem usar `Optional.ofNullable(...).orElse(...)` para garantir que sempre retornem um valor padrão (ex: string vazia ou `BigDecimal.ZERO`).
*   **Estrutura de Pacotes**: O código da aplicação deve seguir a estrutura de pacotes definida em `AGENTS.md`, com separação clara entre `controllers`, `services`, `repository`, `domains`, etc.
*   **Classes Utilitárias**: Classes como `ArquivoUtils` e `Utils` devem ter construtores privados para impedir a instanciação.
