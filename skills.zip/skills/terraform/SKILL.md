# Terraform

## Descrição

Terraform é a ferramenta de Infraestrutura como Código (IaC) utilizada no projeto para provisionar e gerenciar os recursos na AWS de forma declarativa e versionada.

## Fontes de Conhecimento

### Artigos e Documentação

*   [Documentação Oficial do Terraform](https://www.terraform.io/docs) - O principal ponto de partida para aprender sobre o Terraform, seus provedores e sua sintaxe.

## Aplicação no Projeto

O código de infraestrutura está localizado na pasta `/infra/terraform` e é responsável por criar todos os recursos necessários para a execução da aplicação.

*   **Modularização**: O projeto faz uso de um módulo corporativo reutilizável (`itau-hn8-modules-ecs-service`) para provisionar o serviço ECS. Isso é definido em `main.tf` e garante a padronização e a reutilização de código de infraestrutura. O módulo é versionado (`ref=v0.45.1`), o que garante implantações consistentes.

*   **Separação de Responsabilidades**:
    *   `main.tf`: É o ponto de entrada que orquestra a chamada ao módulo principal, passando as configurações necessárias.
    *   `variables.tf`: Define as variáveis de entrada da infraestrutura, como o ambiente (`environment`), nome do cluster (`ecs_cluster_name`) e configurações de rede. Isso permite que a mesma base de código seja usada para diferentes ambientes (dev, hom, prod) apenas alterando os valores das variáveis.
    *   `locals.tf`: Define variáveis locais e constantes usadas para padronizar nomes, tags e configurações específicas do serviço, como as variáveis de ambiente do container (`task_environment_vars`), configuração de logs e health checks.

*   **Configurações Notáveis**:
    *   **Plataforma**: A infraestrutura provisiona um serviço no AWS ECS Fargate.
    *   **Arquitetura**: Está configurado para rodar em `ARM64` (Graviton), visando otimização de custos e performance (`task_runtime_platform`).
    *   **Monitoramento**: O Terraform configura a integração com o Datadog, incluindo APM, logs e health checks, conforme definido no bloco `task_datadog` em `main.tf`.
