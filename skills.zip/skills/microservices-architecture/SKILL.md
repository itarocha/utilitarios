# Arquitetura de Microsserviços

## Descrição

A arquitetura de microsserviços é uma abordagem para o desenvolvimento de aplicações como uma coleção de pequenos serviços independentes. Cada serviço é autônomo, implementa uma única funcionalidade de negócio e se comunica com os outros através de APIs bem definidas.

## Fontes de Conhecimento

### Artigos e Documentação

*   [Microservices.io](https://microservices.io/) - Um guia de referência completo sobre os padrões e as melhores práticas da arquitetura de microsserviços.

## Aplicação no Projeto

A aplicação `entnotas-recebenotas` é um exemplo clássico de um microsserviço dentro de um ecossistema maior.

*   **Escopo Limitado e Focado**: O serviço tem uma responsabilidade clara e única: receber notas, persistir o payload no S3 e notificar outro sistema via SQS. Ele não se preocupa com o processamento posterior dessas notas, que é responsabilidade de outro serviço (o "fluxo whitelabel").
*   **Comunicação Assíncrona**: O uso de uma fila SQS (`SQS_PROCESSA_LOTE`) para notificar o próximo serviço no fluxo é um padrão fundamental em microsserviços para garantir o desacoplamento e a resiliência. Se o serviço de processamento estiver indisponível, as mensagens permanecem na fila para serem processadas mais tarde.
*   **Deploy Independente**: A aplicação é containerizada (Dockerfile) e projetada para ser implantada de forma independente em um cluster ECS, conforme definido pela infraestrutura como código (`infra/terraform`).
*   **Configuração Externalizada**: O uso de variáveis de ambiente (`S3_BUCKET_RECEBE_NOTAS`, `SQS_PROCESSA_LOTE`) e do QuickConfig para configurações dinâmicas (`rs4e1003.recebenotas.canais.origem`) permite que o mesmo artefato de build seja implantado em diferentes ambientes (dev, hom, prod) sem modificação.
