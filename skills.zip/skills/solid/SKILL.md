# Skill: Princípios SOLID

## 1. Descrição

SOLID é um acrônimo mnemônico para cinco princípios de design para programação orientada a objetos, que visam tornar os sistemas de software mais compreensíveis, flexíveis e de fácil manutenção. Quando aplicados corretamente, eles ajudam a evitar código espaguete, a reduzir o acoplamento e a criar um design robusto que é resiliente a mudanças.

Os cinco princípios são:
*   **S** - Single Responsibility Principle (Princípio da Responsabilidade Única)
*   **O** - Open/Closed Principle (Princípio Aberto/Fechado)
*   **L** - Liskov Substitution Principle (Princípio da Substituição de Liskov)
*   **I** - Interface Segregation Principle (Princípio da Segregação de Interfaces)
*   **D** - Dependency Inversion Principle (Princípio da Inversão de Dependência)

---

## 2. Single Responsibility Principle (SRP)

> "Uma classe deve ter um, e apenas um, motivo para mudar."

*   **Objetivo**: Manter as classes pequenas e focadas em uma única responsabilidade ou conceito do negócio.
*   **Vantagens**: Alta coesão, baixo acoplamento, facilidade de entendimento e manutenção.
*   **Sintomas de Violação**: Classes "faz-tudo" (God Classes), métodos que não se relacionam com o nome da classe, uma única mudança de requisito que exige alterações em muitas partes da classe.

### Exemplo de Código

**RUIM (Violação do SRP):** A classe lida com a lógica da nota e também com a forma de persisti-la.

```java
class Nota {
    private String conteudo;

    public Nota(String conteudo) {
        this.conteudo = conteudo;
    }

    public String getConteudo() {
        return this.conteudo;
    }

    // A classe Nota não deveria saber como ser salva.
    public void salvarEmArquivo(String nomeArquivo) {
        // ... lógica para escrever 'conteudo' em um arquivo ...
    }
}
```

**BOM (Aplicação do SRP):** As responsabilidades são separadas.

```java
// A classe Nota só se preocupa com os dados da nota.
class Nota {
    private String conteudo;

    public Nota(String conteudo) {
        this.conteudo = conteudo;
    }

    public String getConteudo() {
        return this.conteudo;
    }
}

// Uma nova classe com a responsabilidade única de persistir.
class RepositorioDeNotas {
    public void salvarEmArquivo(Nota nota, String nomeArquivo) {
        // ... lógica para obter o conteúdo da nota e salvar no arquivo ...
    }
}
```
**No projeto**: `NotasServiceImpl` (lógica de negócio), `S3RepositoryImpl` (persistência S3) e `SqsServiceImpl` (mensageria SQS) são um exemplo perfeito de SRP.

---

## 3. Open/Closed Principle (OCP)

> "As entidades de software (classes, módulos, funções) devem ser abertas para extensão, mas fechadas para modificação."

*   **Objetivo**: Permitir que novos comportamentos sejam adicionados ao sistema sem alterar o código-fonte existente.
*   **Vantagens**: Reduz o risco de introduzir bugs em código que já funciona, melhora a manutenibilidade e a escalabilidade.
*   **Sintomas de Violação**: Longos blocos `if/else` ou `switch` que decidem o comportamento com base em um tipo. Adicionar um novo tipo exige modificar esse bloco.

### Exemplo de Código

**RUIM (Violação do OCP):** Para adicionar um novo método de pagamento, precisamos modificar a classe `CalculadoraDeTaxas`.

```java
class CalculadoraDeTaxas {
    public double calcular(String metodoPagamento, double valor) {
        if (metodoPagamento.equals("cartao_credito")) {
            return valor * 0.05;
        } else if (metodoPagamento.equals("boleto")) {
            return valor * 0.02;
        }
        // E se adicionarmos "pix"? Teremos que adicionar outro "else if".
        return 0;
    }
}
```

**BOM (Aplicação do OCP):** Usamos interfaces e polimorfismo.

```java
// Aberta para extensão: podemos criar novas implementações.
interface EstrategiaDePagamento {
    double calcularTaxa(double valor);
}

class PagamentoCartaoCredito implements EstrategiaDePagamento {
    public double calcularTaxa(double valor) {
        return valor * 0.05;
    }
}

class PagamentoBoleto implements EstrategiaDePagamento {
    public double calcularTaxa(double valor) {
        return valor * 0.02;
    }
}

// Para adicionar "pix", basta criar uma nova classe PagamentoPix.
// A classe CalculadoraDeTaxas está fechada para modificação.
class CalculadoraDeTaxas {
    public double calcular(EstrategiaDePagamento estrategia, double valor) {
        return estrategia.calcularTaxa(valor);
    }
}
```

---

## 4. Liskov Substitution Principle (LSP)

> "Subtipos devem ser substituíveis por seus tipos base sem quebrar a aplicação."

*   **Objetivo**: Garantir que a herança seja usada corretamente, mantendo a consistência do comportamento. Uma subclasse deve honrar o "contrato" da sua superclasse.
*   **Vantagens**: Previsibilidade do código, confiança no polimorfismo.
*   **Sintomas de Violação**: Métodos na subclasse que não fazem nada, lançam exceções inesperadas ou mudam o comportamento esperado da superclasse.

### Exemplo de Código

**RUIM (Violação do LSP):** O exemplo clássico do Quadrado/Retângulo.

```java
class Retangulo {
    protected int altura;
    protected int largura;

    public void setAltura(int altura) { this.altura = altura; }
    public void setLargura(int largura) { this.largura = largura; }
    // ... getters
    public int getArea() { return altura * largura; }
}

// Um Quadrado "é um" Retangulo, certo? Talvez não...
class Quadrado extends Retangulo {
    @Override
    public void setAltura(int lado) {
        super.setAltura(lado);
        super.setLargura(lado); // Quebra a expectativa!
    }
    @Override
    public void setLargura(int lado) {
        super.setAltura(lado); // Quebra a expectativa!
        super.setLargura(lado);
    }
}

// Código cliente que quebra:
Retangulo r = new Quadrado();
r.setAltura(10);
r.setLargura(5);
// O programador esperava uma área de 50, mas será 25!
// A substituição não foi transparente.
assertEquals(50, r.getArea()); // FALHA!
```

**BOM (Aplicação do LSP):** Reconhecer que a herança não é adequada e modelar de outra forma.

```java
// Uma interface comum que não impõe um comportamento que não pode ser compartilhado.
interface Forma {
    int getArea();
}

class Retangulo implements Forma {
    // ... construtor e getters ...
    public int getArea() { /*...*/ }
}

class Quadrado implements Forma {
    // ... construtor e getters ...
    public int getArea() { /*...*/ }
}
```
**No projeto**: As exceções customizadas (`S3UploadException`, etc.) herdam de `RecebeNotasException`. O `NotasExceptionHandler` pode tratar qualquer uma delas através da classe base, sem quebrar, seguindo o LSP.

---

## 5. Interface Segregation Principle (ISP)

> "Os clientes não devem ser forçados a depender de interfaces que não utilizam."

*   **Objetivo**: Manter as interfaces pequenas, coesas e focadas em um único papel. Evitar "interfaces gordas".
*   **Vantagens**: Reduz o acoplamento, melhora a coesão e torna o sistema mais fácil de refatorar e implementar.
*   **Sintomas de Violação**: Classes que implementam métodos da interface lançando `UnsupportedOperationException` ou deixando-os vazios.

### Exemplo de Código

**RUIM (Violação do ISP):** Uma interface "faz-tudo".

```java
// Interface gorda
interface AcoesDaNota {
    void validar();
    void salvarNoBanco();
    void enviarPorEmail();
    void gerarPdf();
}

// Esta classe só precisa validar, mas é forçada a implementar os outros métodos.
class ValidadorDeNota implements AcoesDaNota {
    public void validar() { /* Lógica de validação aqui */ }
    public void salvarNoBanco() { /* Não faz nada */ }
    public void enviarPorEmail() { /* Não faz nada */ }
    public void gerarPdf() { /* Não faz nada */ }
}
```

**BOM (Aplicação do ISP):** Interfaces pequenas e específicas.

```java
// Interfaces segregadas por papel.
interface Validador {
    void validar();
}

interface Persistencia {
    void salvar();
}

interface Notificador {
    void enviar();
}

// A classe agora implementa apenas o que precisa.
class ValidadorDeNota implements Validador {
    public void validar() { /* Lógica de validação aqui */ }
}

class RepositorioDeNotas implements Persistencia {
    public void salvar() { /* Lógica de salvar no banco */ }
}
```

---

## 6. Dependency Inversion Principle (DIP)

> A. "Módulos de alto nível não devem depender de módulos de baixo nível. Ambos devem depender de abstrações."
> B. "Abstrações não devem depender de detalhes. Detalhes devem depender de abstrações."

*   **Objetivo**: Desacoplar as classes, fazendo com que a lógica de negócio (alto nível) não dependa diretamente de detalhes de implementação (baixo nível, como acesso a banco de dados ou a uma API específica).
*   **Vantagens**: Flexibilidade, testabilidade (permite o uso de mocks) e desacoplamento.
*   **Sintomas de Violação**: Uma classe de serviço instanciando um repositório concreto com `new` (`new S3RepositoryImpl()`).

### Exemplo de Código

**RUIM (Violação do DIP):** A classe de alto nível depende diretamente da classe de baixo nível.

```java
// Baixo nível
class S3RepositoryImpl {
    public void salvar(String dados) { /* Lógica do AWS SDK */ }
}

// Alto nível
class NotasService {
    private S3RepositoryImpl s3Repository; // Dependência CONCRETA!

    public NotasService() {
        this.s3Repository = new S3RepositoryImpl(); // Acoplamento forte!
    }

    public void processarNota(String dados) {
        // ...
        s3Repository.salvar(dados);
    }
}
```

**BOM (Aplicação do DIP):** Ambos dependem de uma abstração (interface).

```java
// A Abstração
interface S3Repository {
    void salvar(String dados);
}

// Baixo nível (detalhe) depende da abstração.
class S3RepositoryImpl implements S3Repository {
    public void salvar(String dados) { /* Lógica do AWS SDK */ }
}

// Alto nível depende da abstração.
class NotasService {
    private final S3Repository s3Repository; // Dependência da INTERFACE!

    // A dependência é injetada, não criada aqui.
    public NotasService(S3Repository s3Repository) {
        this.s3Repository = s3Repository;
    }

    public void processarNota(String dados) {
        // ...
        s3Repository.salvar(dados);
    }
}
```
**No projeto**: O Spring Framework é a personificação do DIP. O uso de `@Autowired` ou `@RequiredArgsConstructor` para injetar `S3Repository` em `NotasServiceImpl` é exatamente a aplicação deste princípio. A classe de serviço não sabe qual é a implementação do repositório, apenas que ela segue o contrato da interface.
