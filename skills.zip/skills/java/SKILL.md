# Skill: Java

## 1. Descrição

Java é a linguagem de programação principal do projeto, utilizada na **versão 21**. Esta versão LTS (Long-Term Support) é fundamental para a aplicação, pois introduz melhorias significativas de performance e produtividade, como as Virtual Threads (Project Loom), que são cruciais para aplicações I/O-bound como esta API.

O código-fonte segue os princípios da Programação Orientada a Objetos (OOP) e adota convenções modernas da linguagem para garantir clareza, manutenibilidade e eficiência.

## 2. Fontes de Conhecimento

*   **Documentação Oficial**: [Java 21 Language Features](https://docs.oracle.com/en/java/javase/21/language/)
*   **Guias de Referência**: [Baeldung: What's New in Java 21](https://www.baeldung.com/java-21-new-features)

## 3. Princípios Fundamentais

A aplicação é construída sobre os seguintes pilares do Java e do design de software:

### 3.1. Programação Orientada a Objetos (OOP)

*   **Abstração**: As interfaces (`NotasService`, `S3Repository`) definem contratos claros, escondendo os detalhes da implementação.
*   **Encapsulamento**: As classes de domínio (`Nota`, `Sacado`) protegem seu estado interno, expondo apenas o necessário através de métodos (gerenciados pelo Lombok).
*   **Herança**: Utilizada na hierarquia de exceções customizadas (`S3UploadException extends RecebeNotasException`), permitindo um tratamento de erros polimórfico.
*   **Polimorfismo**: Essencial no tratamento de exceções e na injeção de dependências do Spring, onde a implementação concreta de uma interface pode ser trocada sem alterar o código cliente.

### 3.2. Princípios SOLID

*   **Single Responsibility Principle (SRP)**: Cada classe tem uma responsabilidade clara: `NotasController` (expor a API), `NotasServiceImpl` (orquestrar a lógica de negócio), `S3RepositoryImpl` (persistir no S3).
*   **Open/Closed Principle (OCP)**: O uso de interfaces como `NotasService` permite que novas implementações (ou decorators para logging, métricas) sejam adicionadas sem alterar o código que as consome.
*   **Liskov Substitution Principle (LSP)**: As exceções customizadas podem ser substituídas por sua classe base (`RecebeNotasException`) no `NotasExceptionHandler` sem quebrar o fluxo.
*   **Interface Segregation Principle (ISP)**: As interfaces são coesas e focadas em um único propósito (ex: `SqsService` focado apenas no envio para SQS).
*   **Dependency Inversion Principle (DIP)**: O Spring Framework gerencia a injeção de dependências, garantindo que classes de alto nível (`NotasController`) dependam de abstrações (`NotasService`), não de implementações concretas.

## 4. Concorrência e Performance

*   **Virtual Threads (Project Loom - Java 21)**: Sendo uma API que realiza operações de I/O (rede para S3 e SQS), a aplicação é uma candidata ideal para se beneficiar de Virtual Threads. Elas permitem que o servidor lide com um número muito maior de requisições concorrentes com um consumo de recursos (threads de SO) muito menor, aumentando a vazão e a escalabilidade.
*   **`java.util.concurrent`**: O projeto utiliza estruturas de dados e utilitários deste pacote para garantir a segurança em operações concorrentes, especialmente em singletons gerenciados pelo Spring.

## 5. Gerenciamento de Memória

*   **JVM e Garbage Collection (GC)**: A aplicação roda na Java Virtual Machine (JVM), que gerencia automaticamente a alocação e liberação de memória. O entendimento do Heap e do funcionamento do GC (como o G1GC, padrão em versões recentes) é vital para o tuning de performance e para evitar memory leaks.
*   **Boas Práticas**: O código evita a criação desnecessária de objetos em loops e utiliza `try-with-resources` para garantir o fechamento de recursos (como `InputStream`), prevenindo vazamentos.

## 6. Aplicação no Projeto

*   **Core da Aplicação**: Toda a lógica de negócio, controladores, serviços e repositórios são implementados em Java 21.
*   **Records (Java 16+)**: DTOs como `InformacoesArquivo` são implementados como `records`, reduzindo o boilerplate e garantindo a imutabilidade, o que é ideal para transferência de dados.
*   **Pattern Matching (Java 21)**: Usado para simplificar a verificação de tipos e casting, como em `instanceof` ou em blocos `switch`, tornando o código mais seguro e legível.
*   **Anotações**: O projeto faz uso extensivo de anotações para diversas finalidades:
    *   **Spring**: `@RestController`, `@Service`, `@Repository`, `@SqsListener` para definir componentes e comportamentos.
    *   **Lombok**: `@Getter`, `@Builder`, `@RequiredArgsConstructor` para reduzir código boilerplate.
    *   **Bean Validation**: `@Valid`, `@NotNull` para validação declarativa de DTOs de entrada.
    *   **Datadog**: `@Trace` para instrumentação de performance.
*   **Streams e Lambdas (Java 8+)**: Essenciais para a manipulação de coleções de forma funcional e declarativa. Um exemplo claro é o processamento da lista de `titulos` dentro do `S3Mapper`.
*   **Collections Framework**: Uso intensivo das interfaces `List`, `Set`, `Map` para armazenar e manipular grupos de objetos em memória.
*   **Tratamento de Exceções**: O projeto define uma hierarquia de exceções customizadas (checked e unchecked) e utiliza um `@RestControllerAdvice` (`NotasExceptionHandler`) para centralizar o tratamento de erros e a tradução para respostas HTTP adequadas.
*   **Gerenciamento de Dependências**: O **Maven** (`app/pom.xml`) gerencia todas as dependências do projeto, como Spring Boot, AWS SDK, Lombok e bibliotecas de teste.
