# Padrão Chain of Responsibility

## 1. Problema Resolvido

O padrão Chain of Responsibility (Cadeia de Responsabilidade) cria uma cadeia de objetos "manipuladores" (handlers). Ao receber uma solicitação, ele a passa ao longo da cadeia até que um dos manipuladores a processe.

Ele resolve os seguintes problemas:

- **Acoplamento entre Remetente e Receptor**: O objeto que envia uma solicitação não precisa saber quem será o receptor final. Ele apenas entrega a solicitação ao primeiro elo da cadeia.
- **Lógica de Seleção de Handler**: Evita o uso de grandes blocos `if-else` ou `switch` para decidir qual objeto deve tratar uma determinada solicitação.
- **Flexibilidade na Atribuição de Responsabilidades**: A responsabilidade de tratar uma solicitação pode ser alterada dinamicamente (em tempo de execução) ao modificar a composição da cadeia.

A ideia central é que cada manipulador na cadeia tem a oportunidade de tratar a solicitação. Se ele não puder ou não quiser tratá-la, ele a passa para o próximo manipulador na cadeia.

## 2. Casos de Uso

O padrão Chain of Responsibility é útil em cenários onde:

- **Múltiplos objetos podem tratar uma solicitação**: E o manipulador exato não é conhecido a priori, sendo determinado em tempo de execução.
- **A ordem dos manipuladores é importante**: A solicitação deve passar por uma sequência específica de processamento.
- **Processamento de Eventos em GUI**: Um evento de clique pode ser tratado pelo botão, depois pelo painel que contém o botão, depois pela janela, e assim por diante, até que um deles "consuma" o evento.
- **Filtros de Requisição Web**: Em frameworks web como o Spring Security ou Servlets, as requisições HTTP passam por uma cadeia de filtros (`FilterChain`). Cada filtro pode processar a requisição (ex: autenticação, logging, compressão) e decidir se a passa para o próximo filtro ou se a interrompe.
- **Sistemas de Aprovação**: Uma solicitação de despesa pode precisar ser aprovada por um gerente, depois por um diretor e, finalmente, pelo CFO, dependendo do valor. Cada nível de aprovação é um elo na cadeia.
- **Logging Frameworks**: Um evento de log pode ser processado por diferentes "appenders" (console, arquivo, banco de dados) em uma cadeia.

## 3. Vantagens

- **Desacoplamento**: O remetente da solicitação é completamente desacoplado dos receptores.
- **Princípio da Responsabilidade Única**: Cada manipulador foca em uma única tarefa de processamento.
- **Princípio Aberto/Fechado**: É possível adicionar novos manipuladores à cadeia sem modificar o código cliente ou os manipuladores existentes.
- **Flexibilidade**: A cadeia pode ser montada e reconfigurada dinamicamente.

## 4. Desvantagens

- **Garantia de Processamento**: A solicitação pode chegar ao final da cadeia sem ser tratada por nenhum manipulador, se a cadeia não for configurada corretamente.
- **Dificuldade de Debug**: Rastrear o fluxo de uma solicitação através de uma longa cadeia pode ser complexo.
- **Performance**: Se a cadeia for muito longa, pode haver um impacto no desempenho, pois a solicitação precisa percorrer vários objetos.

## 5. Exemplo de Implementação em Java

### Exemplo: Sistema de Aprovação de Despesas

Vamos modelar um sistema onde uma despesa precisa ser aprovada por diferentes níveis hierárquicos com base no seu valor.

```java
// A solicitação que será passada pela cadeia
class Despesa {
    private final double valor;
    private final String descricao;

    public Despesa(double valor, String descricao) {
        this.valor = valor;
        this.descricao = descricao;
    }

    public double getValor() { return valor; }
    public String getDescricao() { return descricao; }
}

// 1. Interface ou Classe Abstrata do Handler
abstract class Aprovador {
    protected Aprovador proximoAprovador;

    public void setProximo(Aprovador proximo) {
        this.proximoAprovador = proximo;
    }

    // Método que inicia o processamento na cadeia
    public abstract void aprovar(Despesa despesa);
}

// 2. Implementações Concretas dos Handlers
class Gerente extends Aprovador {
    private static final double LIMITE = 1000.00;

    @Override
    public void aprovar(Despesa despesa) {
        if (despesa.getValor() <= LIMITE) {
            System.out.printf("Gerente aprovou a despesa de R$ %.2f (%s).\n", despesa.getValor(), despesa.getDescricao());
        } else if (proximoAprovador != null) {
            System.out.printf("Gerente não pode aprovar. Encaminhando para o próximo nível (despesa de R$ %.2f).\n", despesa.getValor());
            proximoAprovador.aprovar(despesa);
        } else {
            System.out.println("Ninguém na cadeia pôde aprovar a despesa.");
        }
    }
}

class Diretor extends Aprovador {
    private static final double LIMITE = 5000.00;

    @Override
    public void aprovar(Despesa despesa) {
        if (despesa.getValor() <= LIMITE) {
            System.out.printf("Diretor aprovou a despesa de R$ %.2f (%s).\n", despesa.getValor(), despesa.getDescricao());
        } else if (proximoAprovador != null) {
            System.out.printf("Diretor não pode aprovar. Encaminhando para o próximo nível (despesa de R$ %.2f).\n", despesa.getValor());
            proximoAprovador.aprovar(despesa);
        } else {
            System.out.println("Ninguém na cadeia pôde aprovar a despesa.");
        }
    }
}

class CFO extends Aprovador {
    // O CFO pode aprovar qualquer valor, então é o fim da cadeia.
    @Override
    public void aprovar(Despesa despesa) {
        System.out.printf("CFO aprovou a despesa de R$ %.2f (%s).\n", despesa.getValor(), despesa.getDescricao());
    }
}

// 3. Cliente que monta a cadeia e inicia a solicitação
public class SistemaDeDespesas {

    private static Aprovador montarCadeia() {
        // Monta a cadeia de responsabilidade
        Aprovador gerente = new Gerente();
        Aprovador diretor = new Diretor();
        Aprovador cfo = new CFO();

        gerente.setProximo(diretor);
        diretor.setProximo(cfo);

        return gerente; // Retorna o primeiro elo da cadeia
    }

    public static void main(String[] args) {
        Aprovador cadeia = montarCadeia();

        // Despesa pequena, tratada pelo Gerente
        cadeia.aprovar(new Despesa(500, "Material de escritório"));
        System.out.println("---");

        // Despesa média, passada pelo Gerente e tratada pelo Diretor
        cadeia.aprovar(new Despesa(4500, "Viagem de negócios"));
        System.out.println("---");

        // Despesa grande, passada por todos e tratada pelo CFO
        cadeia.aprovar(new Despesa(15000, "Compra de novos servidores"));
        System.out.println("---");

        // Despesa que ninguém pode aprovar (se o CFO tivesse um limite)
        // Ex: Se o CFO só pudesse aprovar até 20000
        // cadeia.aprovar(new Despesa(25000, "Reforma do escritório"));
    }
}
```
Este exemplo demonstra como a solicitação (`Despesa`) flui pela cadeia (`Gerente` -> `Diretor` -> `CFO`) até encontrar um `Aprovador` capaz de processá-la. O código cliente (`SistemaDeDespesas`) não precisa saber dessa lógica, ele apenas dispara a solicitação no início da cadeia.
