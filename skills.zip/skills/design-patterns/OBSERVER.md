# Padrão Observer

## 1. Problema Resolvido

O padrão Observer (Observador) define uma relação de dependência de um-para-muitos entre objetos, de modo que, quando um objeto (o "Subject" ou "Observable") muda de estado, todos os seus dependentes (os "Observers" ou "Listeners") são notificados e atualizados automaticamente.

Ele resolve os seguintes problemas:

- **Acoplamento Forte**: Sem o padrão, o objeto que gera eventos (Subject) precisaria conhecer e chamar diretamente cada um dos objetos que precisam reagir a esses eventos. Isso cria um acoplamento forte, tornando o sistema rígido e difícil de manter. Adicionar um novo "interessado" no evento exigiria modificar o código do Subject.
- **Lógica de Notificação Complexa**: O Subject ficaria poluído com a lógica de notificar diferentes partes do sistema, violando o Princípio da Responsabilidade Única.
- **Inflexibilidade**: É difícil adicionar ou remover "observadores" em tempo de execução.

O Observer promove um acoplamento fraco, permitindo que o Subject notifique qualquer número de Observers sem conhecê-los concretamente, apenas através de uma interface comum.

## 2. Casos de Uso

O padrão Observer é amplamente utilizado em programação orientada a eventos:

- **Interfaces Gráficas (GUI)**: É a base de todos os sistemas de eventos em GUIs. Um botão (Subject) notifica seus `ActionListeners` (Observers) quando é clicado.
- **Sistemas de Mensageria**: Um tópico ou fila (Subject) notifica os consumidores (Observers) quando uma nova mensagem chega. É exatamente o caso do SQS e do `@SqsListener` no projeto.
- **Planilhas Eletrônicas**: Quando o valor de uma célula (Subject) muda, todas as células que dependem dela (Observers) são recalculadas.
- **Notificações em Redes Sociais**: Quando um usuário (Subject) posta uma nova foto, seus seguidores (Observers) são notificados.
- **Spring Framework**: O `ApplicationEventPublisher` do Spring permite que componentes publiquem eventos customizados e outros componentes os escutem com `@EventListener`, implementando o padrão Observer.

No projeto `itau-rs4-app-entnotas-recebenotas`, o `@SqsListener` em `NotasServiceImpl.consumirMensagemSqs` é uma implementação perfeita do padrão. A classe `NotasServiceImpl` atua como um Observer que é notificado pelo framework da AWS (o Subject) sempre que uma nova mensagem aparece na fila `sqs_entnotas-recebenotas`.

## 3. Vantagens

- **Acoplamento Fraco**: O Subject conhece apenas a interface do Observer, não suas implementações concretas.
- **Reutilização**: Observers podem ser reutilizados e aplicados a diferentes Subjects.
- **Extensibilidade**: É fácil adicionar novos Observers sem modificar o código do Subject.
- **Suporte a Broadcast**: Uma única mudança no Subject pode ser comunicada a múltiplos Observers simultaneamente.

## 4. Desvantagens

- **Ordem de Notificação**: O padrão não garante a ordem em que os Observers são notificados. Se a ordem for importante, é preciso adicionar controle extra.
- **Atualizações Inesperadas**: Se a lógica de inscrição e cancelamento não for bem gerenciada, Observers podem continuar recebendo notificações que não esperam mais (vazamento de memória ou "lapsed listener problem").
- **Complexidade no Debug**: O fluxo de controle pode ser difícil de rastrear, pois a lógica é distribuída e acionada por eventos.

## 5. Exemplo de Implementação em Java

### Exemplo Clássico (Manual)

Vamos modelar um sistema de notícias onde assinantes são notificados quando uma nova matéria é publicada.

```java
import java.util.ArrayList;
import java.util.List;

// 1. Interface do Observer
interface Assinante {
    void recebeNoticia(String noticia);
}

// 2. Interface do Subject
interface AgenciaDeNoticias {
    void adicionaAssinante(Assinante assinante);
    void removeAssinante(Assinante assinante);
    void notificaAssinantes();
}

// 3. Implementação Concreta do Subject
class AgenciaDeNoticiasConcreta implements AgenciaDeNoticias {
    private final List<Assinante> assinantes = new ArrayList<>();
    private String ultimaNoticia;

    public void publicaNoticia(String noticia) {
        this.ultimaNoticia = noticia;
        System.out.println("NOVA NOTÍCIA PUBLICADA: " + noticia);
        notificaAssinantes();
    }

    @Override
    public void adicionaAssinante(Assinante assinante) {
        assinantes.add(assinante);
    }

    @Override
    public void removeAssinante(Assinante assinante) {
        assinantes.remove(assinante);
    }

    @Override
    public void notificaAssinantes() {
        for (Assinante assinante : assinantes) {
            assinante.recebeNoticia(ultimaNoticia);
        }
    }
}

// 4. Implementações Concretas do Observer
class LeitorDeEmail implements Assinante {
    private final String email;

    public LeitorDeEmail(String email) {
        this.email = email;
    }

    @Override
    public void recebeNoticia(String noticia) {
        System.out.println("[" + email + "] Recebeu a notícia por email: '" + noticia + "'");
    }
}

class AppNoticias implements Assinante {
    private final String nomeUsuario;

    public AppNoticias(String nomeUsuario) {
        this.nomeUsuario = nomeUsuario;
    }

    @Override
    public void recebeNoticia(String noticia) {
        System.out.println("App do usuário [" + nomeUsuario + "] mostrou notificação: '" + noticia + "'");
    }
}

// 5. Cliente
public class Main {
    public static void main(String[] args) {
        AgenciaDeNoticiasConcreta agencia = new AgenciaDeNoticiasConcreta();

        Assinante leitor1 = new LeitorDeEmail("joao@email.com");
        Assinante app1 = new AppNoticias("maria_app");
        Assinante leitor2 = new LeitorDeEmail("ana@email.com");

        agencia.adicionaAssinante(leitor1);
        agencia.adicionaAssinante(app1);
        agencia.adicionaAssinante(leitor2);

        agencia.publicaNoticia("Java 21 é lançado com novos recursos!");

        System.out.println("\n--- Ana cancelou a assinatura por email ---\n");
        agencia.removeAssinante(leitor2);

        agencia.publicaNoticia("Design Patterns simplificam o desenvolvimento de software.");
    }
}
```

### Exemplo com `@SqsListener` (Contexto do Projeto)

O Spring e a biblioteca `spring-cloud-aws-messaging` abstraem toda a complexidade.

```java
import io.awspring.cloud.messaging.listener.annotation.SqsListener;
import org.springframework.stereotype.Service;

// ... outras importações

@Service
public class NotasServiceImpl implements NotasService {

    // ... outras dependências e métodos ...

    /**
     * Este método é um OBSERVER.
     * O SUBJECT é a infraestrutura da AWS SQS + Spring Cloud.
     * O evento é a chegada de uma nova mensagem na fila.
     */
    @SqsListener(
        value = "${environment.sqs-entnotas-recebenotas}", // Nome da fila que está sendo "observada"
        deletionPolicy = SqsMessageDeletionPolicy.ON_SUCCESS
    )
    public void consumirMensagemSqs(String mensagemPayload) {
        // O framework notifica este método passando o payload da mensagem.
        System.out.println("Nova mensagem recebida da fila: " + mensagemPayload);

        try {
            // Lógica para processar a mensagem...
            // Desserializar, validar e chamar o método processaNota, por exemplo.
        } catch (Exception e) {
            // Tratar erro no consumo da mensagem
            throw new ConsumoSqsException("Falha ao processar mensagem do SQS", e);
        }
    }

    // ... resto da classe ...
}
```
Neste caso, não precisamos criar interfaces `Subject` ou `Observer`, nem gerenciar a lista de assinantes. O framework faz todo o trabalho pesado. Apenas declaramos nossa intenção de "observar" uma fila com uma anotação.
