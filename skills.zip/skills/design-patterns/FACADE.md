# Padrão Facade

## 1. Problema Resolvido

O padrão Facade (Fachada) fornece uma interface simplificada para um sistema complexo, uma biblioteca ou um conjunto de classes. Ele esconde a complexidade interna e expõe apenas o que é necessário, tornando o sistema mais fácil de usar.

Os principais problemas que o Facade resolve são:

- **Alta Complexidade de Uso**: Quando um subsistema é composto por muitas classes e interações, os clientes (outras partes do código) precisam conhecer todos esses detalhes para realizar uma tarefa. Isso aumenta o acoplamento e a complexidade do código cliente.
- **Acoplamento Elevado**: Se os clientes interagem diretamente com dezenas de classes de um subsistema, qualquer mudança interna nesse subsistema pode quebrar os clientes.
- **Dificuldade de Entendimento**: É difícil para um novo desenvolvedor entender como usar um subsistema complexo sem uma "porta de entrada" simples.

O Facade atua como um ponto de entrada único e simplificado, delegando as chamadas do cliente para os objetos corretos dentro do subsistema.

## 2. Casos de Uso

O padrão Facade é extremamente comum e útil em diversas situações:

- **Simplificar o acesso a bibliotecas complexas**: Por exemplo, uma biblioteca de processamento de vídeo pode ter classes para ler codecs, manipular frames, sincronizar áudio, etc. Uma Facade pode fornecer um método simples como `converterVideo(arquivoEntrada, formatoSaida)`.
- **Isolar o código de sistemas legados**: Ao integrar com um sistema antigo e confuso, pode-se criar uma Facade para expor apenas as funcionalidades necessárias de uma maneira moderna e limpa.
- **Arquitetura em Camadas**: A Camada de Serviço (`Service Layer`) em uma aplicação Spring Boot frequentemente atua como uma Facade para a camada de dados e outras lógicas de negócio.

No projeto `itau-rs4-app-entnotas-recebenotas`, a classe `NotasServiceImpl` é um excelente exemplo de Facade. O método `processaNota` orquestra várias operações complexas:
1.  Gera o path do arquivo (`ArquivoUtils`).
2.  Mapeia o DTO (`S3Mapper`).
3.  Faz o upload para o S3 (`S3Repository`).
4.  Publica uma mensagem no SQS (`SqsService`).

O `NotasController`, que é o cliente, não precisa saber de nada disso. Ele simplesmente chama `notasService.processaNota(nota)`.

## 3. Vantagens

- **Desacoplamento**: Isola os clientes da complexidade de um subsistema. Mudanças internas no subsistema não afetam os clientes, desde que a assinatura da Facade permaneça a mesma.
- **Simplicidade**: Torna a API mais fácil de usar e entender.
- **Ponto de Entrada Centralizado**: Fornece um local único para adicionar funcionalidades transversais, como segurança, logging ou caching.
- **Melhora a Legibilidade**: O código cliente fica mais limpo e focado em "o quê" em vez de "como".

## 4. Desvantagens

- **Risco de se tornar um "God Object"**: A Facade pode acabar acumulando muitas responsabilidades e se tornar um objeto grande e complexo, violando o Princípio da Responsabilidade Única.
- **Ocultação de Funcionalidades**: Ao simplificar a interface, a Facade pode esconder funcionalidades úteis do subsistema que poderiam ser necessárias para clientes mais avançados. (Isso pode ser mitigado permitindo o acesso ao subsistema para quem precisar).

## 5. Exemplo de Implementação em Java

### Exemplo Genérico: Sistema de Home Theater

Imagine um sistema de home theater com vários componentes: TV, amplificador, projetor, player de Blu-ray. Ligar tudo para assistir a um filme é complexo.

```java
// Subsistema Complexo
class Amplificador {
    public void ligar() { System.out.println("Amplificador ligado"); }
    public void setVolume(int nivel) { System.out.println("Volume ajustado para " + nivel); }
    public void desligar() { System.out.println("Amplificador desligado"); }
}

class PlayerBluRay {
    public void ligar() { System.out.println("Player de Blu-ray ligado"); }
    public void tocar(String filme) { System.out.println("Tocando filme: " + filme); }
    public void desligar() { System.out.println("Player de Blu-ray desligado"); }
}

class Projetor {
    public void ligar() { System.out.println("Projetor ligado"); }
    public void modoWideScreen() { System.out.println("Projetor em modo widescreen"); }
    public void desligar() { System.out.println("Projetor desligado"); }
}

// A Facade que simplifica tudo
public class HomeTheaterFacade {
    private final Amplificador amp;
    private final PlayerBluRay player;
    private final Projetor projetor;

    public HomeTheaterFacade(Amplificador amp, PlayerBluRay player, Projetor projetor) {
        this.amp = amp;
        this.player = player;
        this.projetor = projetor;
    }

    // Método simplificado que orquestra o subsistema
    public void assistirFilme(String filme) {
        System.out.println("Preparando para assistir a um filme...");
        projetor.ligar();
        projetor.modoWideScreen();
        amp.ligar();
        amp.setVolume(11);
        player.ligar();
        player.tocar(filme);
    }

    // Outro método simplificado
    public void desligarTudo() {
        System.out.println("Desligando o home theater...");
        player.desligar();
        amp.desligar();
        projetor.desligar();
    }
}

// Cliente usando a Facade
public class Cliente {
    public static void main(String[] args) {
        // A inicialização dos componentes ainda pode ser complexa,
        // mas um framework de DI como o Spring resolveria isso.
        Amplificador amp = new Amplificador();
        PlayerBluRay player = new PlayerBluRay();
        Projetor projetor = new Projetor();

        HomeTheaterFacade homeTheater = new HomeTheaterFacade(amp, player, projetor);

        // O cliente só precisa chamar um método!
        homeTheater.assistirFilme("O Senhor dos Anéis");
        System.out.println("\n--- Fim do filme ---\n");
        homeTheater.desligarTudo();
    }
}
```

### Exemplo no Contexto do Projeto (`NotasServiceImpl`)

```java
// A Facade (Service)
@Service
@RequiredArgsConstructor // Lombok para injeção de dependências via construtor
public class NotasServiceImpl implements NotasService {

    private final S3Repository s3Repository;
    private final SqsService sqsService;
    private final MetricasService metricasService;
    // Outras dependências...

    @Override
    public void processaNota(Nota nota) {
        try {
            // 1. Orquestra a geração do nome do arquivo
            String nomeExecucao = ArquivoUtils.montarNomeExecucao(nota.getCanalOrigem(), nota.getSacado().getDocumento());
            String pathArquivo = ArquivoUtils.montarPathArquivo(
                nota.getCanalOrigem(),
                nota.getSacado().getDocumento(),
                nota.getCorrelationId()
            );

            // 2. Orquestra o mapeamento e o upload para o S3
            NotaDto notaDto = S3Mapper.mapToS3(nota);
            s3Repository.uploadJson(s3Bucket, pathArquivo, notaDto);
            metricasService.incrementaUploadS3Sucesso(nota.getCanalOrigem());

            // 3. Orquestra a publicação da mensagem SQS
            InformacoesArquivo infoArquivo = new InformacoesArquivo(s3Bucket, pathArquivo);
            sqsService.publicarMensagem(infoArquivo, nota.getCorrelationId(), nomeExecucao);
            metricasService.incrementaEnvioSqsSucesso(nota.getCanalOrigem());

        } catch (Exception e) {
            // Tratamento de erro centralizado
            metricasService.incrementaErroProcessamento(nota.getCanalOrigem());
            throw new ProcessamentoNotaException("Erro ao processar a nota.", e);
        }
    }
}

// O Cliente (Controller)
@RestController
@RequestMapping("/v1/notas")
@RequiredArgsConstructor
public class NotasController {

    private final NotasService notasService; // A Facade

    @PostMapping
    public ResponseEntity<Void> recebeNotas(@Valid @RequestBody Nota nota) {
        // O controller não sabe sobre S3, SQS, mappers, etc.
        // Ele apenas delega a tarefa para a Facade.
        notasService.processaNota(nota);
        return ResponseEntity.accepted().build();
    }
}
```

