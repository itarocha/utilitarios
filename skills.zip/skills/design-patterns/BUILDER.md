# Padrão Builder

## 1. Problema Resolvido

O padrão Builder resolve o problema de criar objetos complexos com múltiplas partes ou configurações. Quando um objeto precisa ser construído com muitos parâmetros, usar construtores ou setters pode se tornar confuso e propenso a erros.

- **Construtores Telescópicos**: Ter múltiplos construtores com diferentes combinações de parâmetros (o padrão "telescoping constructor") torna o código difícil de ler e manter. É fácil se confundir com a ordem e o tipo dos parâmetros.
- **JavaBeans com Setters**: Criar um objeto com um construtor vazio e depois chamar vários setters (`set...()`) pode deixar o objeto em um estado inconsistente durante o processo de construção. Além disso, não há como garantir que todos os parâmetros necessários foram definidos.

O Builder oferece uma solução fluente e legível para construir um objeto passo a passo, garantindo que ele seja imutável e consistente ao final do processo.

## 2. Casos de Uso

O padrão Builder é ideal em situações como:

- **Criação de DTOs e Entidades**: Especialmente quando eles têm muitos campos opcionais e obrigatórios.
- **Construção de objetos de configuração**: Como `HttpClient`, `RestTemplate` ou configurações de conexão com banco de dados, que podem ter dezenas de opções (timeout, pool de conexões, proxy, etc.).
- **Geração de relatórios ou documentos**: Onde o documento final é composto por várias partes (cabeçalho, corpo, rodapé) que podem ser adicionadas em qualquer ordem.
- **Criação de queries SQL**: Um `QueryBuilder` pode montar uma consulta SQL complexa de forma programática e segura.

No projeto `itau-rs4-app-entnotas-recebenotas`, o Lombok (`@Builder`, `@SuperBuilder`) é usado para criar DTOs como `NotaDto` e objetos de domínio como `Nota`, simplificando a instanciação desses objetos.

## 3. Vantagens

- **Legibilidade**: O código de construção se torna mais claro e descritivo (ex: `new Carro.Builder().comMotor("V8").comCor("Vermelho").construir()`).
- **Imutabilidade**: O Builder pode produzir um objeto imutável, o que é excelente para concorrência e segurança.
- **Flexibilidade**: Permite a criação de diferentes representações do mesmo objeto, reutilizando o mesmo processo de construção.
- **Validação Centralizada**: A lógica de validação pode ser colocada no método `build()`, garantindo que o objeto só seja criado se estiver em um estado válido.
- **Redução de Construtores**: Elimina a necessidade do padrão "telescoping constructor".

## 4. Desvantagens

- **Verbosidade**: Requer a criação de uma classe `Builder` separada para cada objeto que precisa ser construído, o que aumenta o número de classes no projeto. (Frameworks como o Lombok mitigam esse problema).
- **Complexidade Inicial**: Para objetos simples, o padrão pode ser um exagero e adicionar complexidade desnecessária.

## 5. Exemplo de Implementação em Java

### Exemplo Clássico (sem Lombok)

```java
// Objeto complexo a ser construído
public class Pizza {
    private final String massa;
    private final String molho;
    private final String cobertura;
    private final boolean queijoExtra;

    // Construtor privado para forçar o uso do Builder
    private Pizza(Builder builder) {
        this.massa = builder.massa;
        this.molho = builder.molho;
        this.cobertura = builder.cobertura;
        this.queijoExtra = builder.queijoExtra;
    }

    // Getters...
    @Override
    public String toString() {
        return "Pizza [massa=" + massa + ", molho=" + molho + ", cobertura=" + cobertura + ", queijoExtra=" + queijoExtra + "]";
    }

    // Classe Builder estática aninhada
    public static class Builder {
        // Parâmetros obrigatórios
        private final String massa;
        private final String molho;

        // Parâmetros opcionais
        private String cobertura = "Mussarela"; // Valor padrão
        private boolean queijoExtra = false;

        public Builder(String massa, String molho) {
            this.massa = massa;
            this.molho = molho;
        }

        public Builder comCobertura(String cobertura) {
            this.cobertura = cobertura;
            return this; // Retorna o próprio builder para chamadas fluentes
        }

        public Builder comQueijoExtra(boolean queijoExtra) {
            this.queijoExtra = queijoExtra;
            return this;
        }

        // Método final que constrói o objeto
        public Pizza construir() {
            // Aqui poderíamos adicionar validações
            if (massa == null || molho == null) {
                throw new IllegalStateException("Massa e molho são obrigatórios.");
            }
            return new Pizza(this);
        }
    }
}

// Uso do Builder
public class Pizzaria {
    public static void main(String[] args) {
        Pizza pizzaCalabresa = new Pizza.Builder("Fina", "Tomate")
            .comCobertura("Calabresa")
            .comQueijoExtra(true)
            .construir();

        System.out.println(pizzaCalabresa); // Saída: Pizza [massa=Fina, molho=Tomate, cobertura=Calabresa, queijoExtra=true]

        Pizza pizzaSimples = new Pizza.Builder("Grossa", "Pesto").construir();
        System.out.println(pizzaSimples); // Saída: Pizza [massa=Grossa, molho=Pesto, cobertura=Mussarela, queijoExtra=false]
    }
}
```

### Exemplo com Lombok (usado no projeto)

Com Lombok, o código acima é drasticamente simplificado.

```java
import lombok.Builder;
import lombok.ToString;

@Builder
@ToString
public class PizzaLombok {
    @Builder.Default
    private String massa = "Fina";
    private String molho;
    @Builder.Default
    private String cobertura = "Mussarela";
    private boolean queijoExtra;
}

// Uso do Builder gerado pelo Lombok
public class PizzariaLombok {
    public static void main(String[] args) {
        PizzaLombok pizza = PizzaLombok.builder()
            .molho("Tomate")
            .cobertura("Frango com Catupiry")
            .queijoExtra(true)
            .build();

        System.out.println(pizza);
    }
}
```

