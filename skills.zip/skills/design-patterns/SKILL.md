# Design Patterns

## Descrição

Design Patterns (Padrões de Projeto) são soluções reutilizáveis para problemas comuns que ocorrem no design de software. Eles representam as melhores práticas utilizadas por desenvolvedores experientes para resolver problemas recorrentes.

## Fontes de Conhecimento

### Artigos e Documentação

*   [Design Pattern Series](https://www.baeldung.com/design-patterns-series) - Uma série de artigos do Baeldung que cobre os principais padrões de projeto com exemplos em Java.

## Aplicação no Projeto

*   **Builder**: Utilizado extensivamente via anotações do Lombok como `@Builder` e `@SuperBuilder` para a construção de DTOs (`NotaDto`, `TituloDto`) e objetos de domínio (`Nota`). Isso facilita a criação de objetos complexos com muitos campos.
*   **Adapter**: O `S3Mapper` atua como um Adapter, convertendo o objeto de domínio `Nota` para o `NotaDto`, que é o formato esperado para persistência no S3. Ele adapta a interface de um objeto para outra.
*   **Singleton**: O Spring Framework gerencia a maioria dos seus beans (como Services, Repositories e Controllers) como Singletons por padrão. Isso garante que exista apenas uma instância dessas classes na JVM, economizando recursos.
*   **Observer (Listener)**: O mecanismo `@SqsListener` em `NotasServiceImpl.consumirMensagemSqs` é uma implementação do padrão Observer. A classe "escuta" por novas mensagens na fila SQS e reage (executa o método) quando uma nova mensagem chega.
*   **Facade**: A classe `NotasServiceImpl` pode ser vista como uma Facade, pois fornece uma interface simplificada (`processaNota`) para um subsistema complexo que envolve validação, orquestração da gravação no S3 e publicação no SQS.

## Padrões Detalhados

Para um aprofundamento em padrões de projeto específicos com exemplos de código, consulte os seguintes documentos:

*   **Padrões Criacionais**:
    *   [Builder](./BUILDER.md)
    *   [Factory Method](./FACTORY_METHOD.md)
    *   [Abstract Factory](./ABSTRACT_FACTORY.md)

*   **Padrões Estruturais**:
    *   [Facade](./FACADE.md)

*   **Padrões Comportamentais**:
    *   [Observer](./OBSERVER.md)
    *   [Strategy](./STRATEGY.md)
    *   [Chain of Responsibility](./CHAIN_OF_RESPONSIBILITY.md)

*   **Outros Padrões**:
    *   [Repository](./REPOSITORY.md)
