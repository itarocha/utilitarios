# Padrão Abstract Factory

## 1. Problema Resolvido

O padrão Abstract Factory (Fábrica Abstrata) é um padrão de criação que permite produzir famílias de objetos relacionados ou dependentes sem especificar suas classes concretas. Ele é como uma "fábrica de fábricas".

Ele resolve um problema um nível acima do Factory Method:

- **Criação de Famílias de Objetos**: Imagine que você precisa criar um conjunto de objetos que devem ser compatíveis entre si. Por exemplo, em uma interface gráfica, você pode ter temas "Claro" e "Escuro". O tema "Claro" requer um `BotaoClaro`, uma `JanelaClara` e uma `BarraDeRolagemClara`. O tema "Escuro" requer um `BotaoEscuro`, uma `JanelaEscura` e uma `BarraDeRolagemEscura`.
- **Acoplamento entre Famílias**: Sem o padrão, o código cliente precisaria saber qual conjunto de classes usar. Haveria `if-else` para decidir se cria um `BotaoClaro` ou um `BotaoEscuro`, e seria fácil misturar componentes (usar um `BotaoClaro` em uma `JanelaEscura`), quebrando a consistência visual.

A Abstract Factory define uma interface para criar todos os produtos de uma família (ex: `criarBotao()`, `criarJanela()`). Classes de fábrica concretas (`FabricaTemaClaro`, `FabricaTemaEscuro`) implementam essa interface para criar os produtos de sua família específica. O cliente usa a fábrica abstrata e não tem ideia de qual tema (família de produtos) está sendo usado, garantindo a consistência.

## 2. Casos de Uso

O padrão Abstract Factory é ideal quando:

- **O sistema precisa ser independente de como seus produtos são criados, compostos e representados.**
- **O sistema deve ser configurado com uma de múltiplas famílias de produtos.**
- **Os objetos de uma família devem ser usados juntos**, e você precisa garantir essa restrição.
- **Você quer fornecer uma biblioteca de classes e expor apenas suas interfaces, não suas implementações.**

Exemplos práticos:
- **Kits de UI (GUI)**: Como no exemplo dos temas Claro/Escuro, ou para criar componentes para diferentes sistemas operacionais (botões/janelas de Windows vs. macOS vs. Linux).
- **Suporte a Diferentes Bancos de Dados**: Uma fábrica abstrata `DBFactory` poderia ter métodos `createConnection()`, `createCommand()`, `createTransaction()`. Fábricas concretas como `OracleFactory` e `SqlServerFactory` implementariam esses métodos para retornar objetos específicos da Oracle ou do SQL Server, garantindo que todos os componentes de banco de dados usados em uma operação sejam do mesmo fornecedor.
- **Suporte a Formatos de Documentos**: Uma `DocumentFactory` poderia criar objetos para `ler()`, `escrever()` e `validar()` diferentes tipos de documentos (XML, JSON, YAML), garantindo que todas as operações usem as ferramentas corretas para um formato específico.

## 3. Vantagens

- **Garante a Compatibilidade**: Os produtos criados por uma mesma fábrica concreta são projetados para funcionar juntos.
- **Desacoplamento Forte**: O código cliente é completamente isolado das classes concretas dos produtos. Ele só depende das interfaces abstratas da fábrica e dos produtos.
- **Princípio da Responsabilidade Única**: A lógica de criação de uma família de produtos é centralizada em uma única classe de fábrica.
- **Princípio Aberto/Fechado**: É fácil introduzir novas famílias de produtos (novas variantes) sem modificar o código cliente. Basta criar uma nova fábrica concreta.

## 4. Desvantagens

- **Aumento da Complexidade**: O padrão introduz muitas novas interfaces e classes (fábrica abstrata, fábricas concretas, produtos abstratos, produtos concretos), o que pode tornar o código mais complexo se a necessidade não for clara.
- **Dificuldade para Adicionar Novos Produtos**: Adicionar um novo tipo de produto (ex: `criarCheckbox()`) à família é difícil. Isso exigiria a alteração da interface da fábrica abstrata e de todas as suas subclasses concretas, violando o Princípio Aberto/Fechado.

## 5. Exemplo de Implementação em Java

### Exemplo: Fábrica de Móveis para Diferentes Estilos

Vamos criar um sistema que produz famílias de móveis (Cadeira, Sofá, Mesa de Centro) em diferentes estilos (Vitoriano, Moderno).

```java
// 1. Interfaces dos Produtos Abstratos (a família de objetos)
interface Cadeira {
    void sentar();
    String getEstilo();
}

interface Sofa {
    void deitar();
    String getEstilo();
}

// 2. Implementações Concretas dos Produtos para o estilo "Moderno"
class CadeiraModerna implements Cadeira {
    @Override public void sentar() { System.out.println("Sentando em uma cadeira moderna."); }
    @Override public String getEstilo() { return "Moderno"; }
}

class SofaModerno implements Sofa {
    @Override public void deitar() { System.out.println("Deitando em um sofá moderno."); }
    @Override public String getEstilo() { return "Moderno"; }
}

// 3. Implementações Concretas dos Produtos para o estilo "Vitoriano"
class CadeiraVitoriana implements Cadeira {
    @Override public void sentar() { System.out.println("Sentando em uma cadeira vitoriana."); }
    @Override public String getEstilo() { return "Vitoriano"; }
}

class SofaVitoriano implements Sofa {
    @Override public void deitar() { System.out.println("Deitando em um sofá vitoriano."); }
    @Override public String getEstilo() { return "Vitoriano"; }
}

// 4. A Interface da Fábrica Abstrata
// Define métodos para criar cada produto da família.
interface FabricaDeMoveis {
    Cadeira criarCadeira();
    Sofa criarSofa();
}

// 5. Implementações Concretas da Fábrica
// Cada fábrica cria produtos de um estilo (família) específico.
class FabricaDeMoveisModernos implements FabricaDeMoveis {
    @Override
    public Cadeira criarCadeira() {
        return new CadeiraModerna();
    }
    @Override
    public Sofa criarSofa() {
        return new SofaModerno();
    }
}

class FabricaDeMoveisVitorianos implements FabricaDeMoveis {
    @Override
    public Cadeira criarCadeira() {
        return new CadeiraVitoriana();
    }
    @Override
    public Sofa criarSofa() {
        return new SofaVitoriano();
    }
}

// 6. Cliente
public class LojaDeMoveis {

    private final Cadeira cadeira;
    private final Sofa sofa;

    // O cliente recebe uma fábrica e a usa para criar seus objetos.
    // Ele não sabe (e não se importa) qual estilo está sendo criado.
    public LojaDeMoveis(FabricaDeMoveis fabrica) {
        System.out.println("Configurando a loja com móveis de estilo...");
        this.cadeira = fabrica.criarCadeira();
        this.sofa = fabrica.criarSofa();
    }

    public void demonstrarMoveis() {
        System.out.println("Estilo da cadeira: " + cadeira.getEstilo());
        cadeira.sentar();
        System.out.println("Estilo do sofá: " + sofa.getEstilo());
        sofa.deitar();
    }

    public static void main(String[] args) {
        // A configuração da aplicação decide qual fábrica usar.
        String estiloDesejado = "vitoriano"; // ou "moderno"
        FabricaDeMoveis fabrica;

        if (estiloDesejado.equalsIgnoreCase("moderno")) {
            fabrica = new FabricaDeMoveisModernos();
        } else if (estiloDesejado.equalsIgnoreCase("vitoriano")) {
            fabrica = new FabricaDeMoveisVitorianos();
        } else {
            throw new IllegalArgumentException("Estilo de móvel desconhecido.");
        }

        // O cliente é instanciado com a fábrica escolhida.
        LojaDeMoveis loja = new LojaDeMoveis(fabrica);

        // A demonstração usará a família de produtos correta, garantindo consistência.
        loja.demonstrarMoveis();
    }
}
```
Neste exemplo, `LojaDeMoveis` é o cliente. Ele é construído com uma `FabricaDeMoveis` e não tem ideia se está lidando com móveis modernos ou vitorianos. Isso garante que a loja nunca terá uma `CadeiraModerna` e um `SofaVitoriano` ao mesmo tempo, mantendo a consistência do "tema".
