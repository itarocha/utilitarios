# Padrão Factory Method

## 1. Problema Resolvido

O padrão Factory Method (Método de Fábrica) é um padrão de criação que fornece uma interface para criar objetos em uma superclasse, mas permite que as subclasses alterem o tipo de objetos que serão criados.

Ele resolve os seguintes problemas:

- **Acoplamento com Classes Concretas**: Quando o código cliente cria um objeto diretamente usando o operador `new`, ele fica acoplado à implementação concreta daquele objeto. Isso torna difícil mudar a implementação ou introduzir novos tipos de objetos sem alterar o código cliente.
- **Lógica de Criação Complexa**: Se a criação de um objeto envolve uma lógica complexa (configurações, dependências, etc.), essa lógica acaba espalhada por todo o código onde o objeto é instanciado.
- **Violação do Princípio Aberto/Fechado**: Para introduzir um novo tipo de produto, você precisa modificar o código cliente para que ele possa instanciar o novo tipo.

O Factory Method delega a responsabilidade da instanciação para um "método de fábrica". A classe que usa o objeto (o "Creator") não sabe qual classe concreta será instanciada. Ela apenas chama o método de fábrica, e uma subclasse do Creator decide qual objeto específico criar.

## 2. Casos de Uso

O padrão Factory Method é útil quando:

- **Uma classe não pode antecipar o tipo de objetos que deve criar**: A classe quer que suas subclasses especifiquem os objetos que ela cria.
- **Uma classe delega responsabilidades para subclasses auxiliares**: E você quer localizar o conhecimento de qual subclasse auxiliar é a correta para cada caso.
- **Você quer fornecer aos usuários de uma biblioteca ou framework uma maneira de estender seus componentes internos**: Por exemplo, um framework de UI pode fornecer uma classe `Janela` com um método `criarBotao()`. Os desenvolvedores podem estender `Janela` e sobrescrever `criarBotao()` para retornar um `BotaoEstilizado`, sem precisar alterar a classe `Janela` original.
- **Conexões com Bancos de Dados**: Uma classe abstrata `DatabaseConnector` pode ter um método `createConnection()`. Subclasses como `OracleConnector` e `PostgresConnector` implementariam esse método para retornar uma `OracleConnection` ou `PostgresConnection`, respectivamente.

## 3. Vantagens

- **Desacoplamento**: O código cliente (ou a superclasse Creator) trabalha com a interface do produto, não com sua implementação concreta.
- **Princípio da Responsabilidade Única**: A lógica de criação do objeto é isolada em um único lugar, tornando o código mais fácil de manter.
- **Princípio Aberto/Fechado**: É possível introduzir novos tipos de produtos (classes concretas) sem modificar o código cliente. Basta criar uma nova subclasse do Creator que implemente o método de fábrica.
- **Flexibilidade**: As subclasses têm controle total sobre o tipo de objeto a ser criado.

## 4. Desvantagens

- **Aumento do Número de Classes**: O padrão requer a criação de uma hierarquia de classes (Creators e Produtos), o que pode aumentar a complexidade do código se houver muitos tipos de produtos.

## 5. Exemplo de Implementação em Java

### Exemplo: Sistema de Logística para Diferentes Tipos de Transporte

Vamos criar um sistema que planeja a entrega de cargas, mas o meio de transporte (caminhão ou navio) é decidido pela subclasse.

```java
// 1. Interface do Produto
interface Transporte {
    void entregar();
}

// 2. Implementações Concretas do Produto
class Caminhao implements Transporte {
    @Override
    public void entregar() {
        System.out.println("Entrega sendo realizada por via terrestre (Caminhão).");
    }
}

class Navio implements Transporte {
    @Override
    public void entregar() {
        System.out.println("Entrega sendo realizada por via marítima (Navio).");
    }
}

// 3. Classe Abstrata do Creator (Criador)
// Esta classe contém a lógica de negócio que usa o produto.
abstract class Logistica {

    // A lógica de negócio principal que não depende do tipo de transporte.
    public void planejarEntrega() {
        // O método de fábrica é chamado para obter o objeto de transporte.
        Transporte t = criarTransporte();
        // Agora, a lógica de negócio pode usar o produto sem saber sua classe concreta.
        System.out.println("Plano de entrega definido. Executando a entrega...");
        t.entregar();
    }

    // O Factory Method abstrato. As subclasses devem implementá-lo.
    public abstract Transporte criarTransporte();
}

// 4. Implementações Concretas do Creator
// Cada subclasse decide qual produto concreto instanciar.
class LogisticaTerrestre extends Logistica {
    // Sobrescreve o método de fábrica para retornar um Caminhão.
    @Override
    public Transporte criarTransporte() {
        return new Caminhao();
    }
}

class LogisticaMaritima extends Logistica {
    // Sobrescreve o método de fábrica para retornar um Navio.
    @Override
    public Transporte criarTransporte() {
        return new Navio();
    }
}

// 5. Cliente
public class Aplicacao {
    private static Logistica logistica;

    public static void main(String[] args) {
        // A configuração da aplicação decide qual tipo de logística usar.
        // Isso poderia vir de um arquivo de configuração, variável de ambiente, etc.
        String tipoLogistica = "maritima"; // ou "terrestre"

        if (tipoLogistica.equals("terrestre")) {
            logistica = new LogisticaTerrestre();
        } else if (tipoLogistica.equals("maritima")) {
            logistica = new LogisticaMaritima();
        } else {
            throw new IllegalArgumentException("Tipo de logística desconhecido.");
        }

        // O código cliente chama a lógica de negócio na classe base,
        // sem se preocupar com os detalhes da criação do transporte.
        logistica.planejarEntrega();

        // Se mudarmos para "terrestre", o resultado muda sem alterar esta chamada.
        // logistica = new LogisticaTerrestre();
        // logistica.planejarEntrega();
    }
}
```
Neste exemplo, a classe `Logistica` tem a lógica de `planejarEntrega`, mas não sabe como criar o objeto `Transporte`. Ela delega essa responsabilidade para suas subclasses (`LogisticaTerrestre`, `LogisticaMaritima`) através do método abstrato `criarTransporte()`. Isso permite que a lógica de planejamento seja reutilizada enquanto o meio de transporte pode variar.
