# Padrão Repository

## 1. Problema Resolvido

O padrão Repository atua como uma camada de abstração entre a lógica de negócios e a fonte de dados (banco de dados, API externa, sistema de arquivos, etc.). Ele resolve os seguintes problemas:

- **Acoplamento com a Fonte de Dados**: Sem o Repository, a lógica de negócios fica diretamente acoplada à tecnologia de persistência (ex: código JDBC, JPA, ou SDKs de serviços específicos como AWS S3). Isso torna a troca da fonte de dados ou a atualização da tecnologia uma tarefa complexa e arriscada.
- **Código Duplicado**: As consultas e operações de acesso a dados tendem a se repetir em várias partes da aplicação.
- **Dificuldade de Teste**: Testar a lógica de negócios se torna difícil, pois ela depende de uma conexão real com o banco de dados ou outro serviço externo.
- **Mistura de Responsabilidades**: As classes de serviço acabam contendo tanto a lógica de negócios quanto a lógica de acesso a dados, violando o Princípio da Responsabilidade Única (SRP).

O Repository centraliza o acesso aos dados, fornecendo uma interface limpa e orientada a objetos que se parece com uma "coleção de objetos de domínio", escondendo os detalhes de como os dados são realmente buscados ou persistidos.

## 2. Casos de Uso

O padrão Repository é fundamental em aplicações que precisam de uma camada de persistência, como:

- **Aplicações CRUD**: Qualquer aplicação que cria, lê, atualiza e exclui dados de uma fonte.
- **Arquitetura em Camadas**: É a peça central da Camada de Acesso a Dados (*Data Access Layer*).
- **Múltiplas Fontes de Dados**: Quando uma aplicação precisa buscar dados de diferentes lugares (ex: um banco de dados relacional e uma API REST), o Repository pode unificar o acesso a essas fontes sob uma única abstração.
- **Aplicações que necessitam de Caching**: A implementação do Repository pode encapsular a lógica de cache, tornando-a transparente para a camada de serviço.

No projeto `itau-rs4-app-entnotas-recebenotas`, o `S3RepositoryImpl` é um exemplo claro. Ele abstrai a complexidade do SDK da AWS S3 para upload de arquivos, fornecendo um método simples (`uploadJson`) para a camada de serviço.

## 3. Vantagens

- **Desacoplamento**: Isola a lógica de negócios dos detalhes da persistência, facilitando a troca da tecnologia de banco de dados (ex: migrar de Oracle para PostgreSQL, ou de S3 para um banco NoSQL).
- **Testabilidade**: Permite que a camada de serviço seja testada de forma isolada, usando um *mock* (simulação) do Repository.
- **Centralização do Acesso a Dados**: Evita a duplicação de código de consulta e acesso a dados.
- **Código Mais Limpo**: A lógica de negócios fica mais focada e livre de detalhes de infraestrutura.

## 4. Desvantagens

- **Abstração Adicional**: Para aplicações muito simples, pode adicionar uma camada de complexidade desnecessária.
- **Risco de "Leaky Abstraction"**: Às vezes, detalhes da tecnologia de persistência subjacente "vazam" para a interface do repositório (ex: métodos que expõem funcionalidades específicas de um determinado tipo de banco de dados), comprometendo a abstração.

## 5. Exemplo de Implementação em Java

### Exemplo com Spring Data JPA (o mais comum em aplicações Spring)

O Spring Data JPA eleva o padrão Repository a um novo nível, gerando a implementação automaticamente a partir de uma interface.

```java
// 1. Entidade de Domínio
@Entity
public class Usuario {
    @Id
    @GeneratedValue
    private Long id;
    private String nome;
    private String email;
    // Getters e Setters
}

// 2. Interface do Repository
// Estendemos JpaRepository, que já fornece os métodos CRUD básicos (save, findById, findAll, delete, etc.)
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    // O Spring Data JPA cria a implementação dessa consulta automaticamente
    // com base no nome do método.
    Optional<Usuario> findByEmail(String email);

    // Também podemos usar a anotação @Query para consultas mais complexas
    @Query("SELECT u FROM Usuario u WHERE u.nome LIKE %:nome%")
    List<Usuario> findByNomeContendo(@Param("nome") String nome);
}

// 3. Camada de Serviço (Consumidor do Repository)
@Service
public class UsuarioService {
    private final UsuarioRepository usuarioRepository;

    @Autowired
    public UsuarioService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    public Usuario criarUsuario(String nome, String email) {
        if (usuarioRepository.findByEmail(email).isPresent()) {
            throw new IllegalStateException("Email já cadastrado.");
        }
        Usuario novoUsuario = new Usuario();
        novoUsuario.setNome(nome);
        novoUsuario.setEmail(email);
        return usuarioRepository.save(novoUsuario);
    }

    public Optional<Usuario> buscarPorEmail(String email) {
        return usuarioRepository.findByEmail(email);
    }
}
```

### Exemplo Manual (como no `S3RepositoryImpl`)

Neste caso, criamos a interface e a implementação manualmente, pois não há um framework que gere o código para nossa necessidade específica (interagir com o S3).

```java
// 1. Interface do Repository
public interface S3Repository {
    void uploadJson(String bucket, String path, Object data) throws S3UploadException;
}

// 2. Implementação do Repository
@Repository // Anotação do Spring para indicar que é um componente de persistência
public class S3RepositoryImpl implements S3Repository {

    private final AmazonS3 s3Client;
    private final ObjectMapper objectMapper;

    @Autowired
    public S3RepositoryImpl(AmazonS3 s3Client, ObjectMapper objectMapper) {
        this.s3Client = s3Client;
        this.objectMapper = objectMapper;
    }

    @Override
    public void uploadJson(String bucket, String path, Object data) throws S3UploadException {
        try {
            String jsonContent = objectMapper.writeValueAsString(data);
            byte[] contentAsBytes = jsonContent.getBytes(StandardCharsets.UTF_8);

            ObjectMetadata metadata = new ObjectMetadata();
            metadata.setContentLength(contentAsBytes.length);
            metadata.setContentType("application/json");

            try (InputStream inputStream = new ByteArrayInputStream(contentAsBytes)) {
                s3Client.putObject(new PutObjectRequest(bucket, path, inputStream, metadata));
            }
            // Log de sucesso...
        } catch (JsonProcessingException e) {
            // Log de erro...
            throw new S3UploadException("Erro ao serializar o objeto para JSON.", e);
        } catch (AmazonServiceException e) {
            // Log de erro...
            throw new S3UploadException("Erro de serviço da AWS ao fazer upload para o S3.", e);
        } catch (Exception e) {
            // Log de erro...
            throw new S3UploadException("Erro inesperado ao fazer upload para o S3.", e);
        }
    }
}

// 3. Camada de Serviço (Consumidor)
@Service
public class NotasServiceImpl implements NotasService {
    // ...
    private final S3Repository s3Repository;
    // ...

    public void processaNota(Nota nota) {
        // ... lógica de negócios ...
        String path = ArquivoUtils.montarPathArquivo(...);
        NotaDto notaDto = S3Mapper.mapToS3(nota);

        // A camada de serviço não sabe nada sobre o SDK da AWS, apenas chama o método do repositório.
        s3Repository.uploadJson(s3Bucket, path, notaDto);

        // ... resto da lógica ...
    }
}
```

