# Padrão Strategy

## 1. Problema Resolvido

O padrão Strategy (Estratégia) permite definir uma família de algoritmos, encapsular cada um deles em uma classe separada e torná-los intercambiáveis. Isso permite que o algoritmo varie independentemente dos clientes que o utilizam.

Ele resolve os seguintes problemas:

- **Múltiplos `if-else` ou `switch`**: Quando uma classe tem um método que se comporta de maneiras diferentes dependendo de uma condição, é comum ver uma cascata de `if-else` ou um `switch`. Isso torna a classe grande, complexa e difícil de manter. Adicionar um novo comportamento exige modificar a classe existente, violando o Princípio Aberto/Fechado.
- **Lógica Condicional Complexa**: A classe principal fica poluída com a responsabilidade de saber como e quando executar cada variação do algoritmo.
- **Dificuldade de Reutilização**: Os algoritmos ficam presos dentro da classe que os utiliza, dificultando sua reutilização em outros contextos.

O Strategy extrai esses algoritmos para classes separadas (as "estratégias"), que compartilham uma interface comum. A classe principal (o "contexto") recebe um objeto de estratégia e o utiliza para executar o trabalho, sem precisar saber qual algoritmo específico está sendo executado.

## 2. Casos de Uso

O padrão Strategy é ideal quando:

- **Várias formas de fazer a mesma coisa**: Você tem diferentes maneiras de realizar uma tarefa e quer alternar entre elas.
- **Validação de Dados**: Diferentes tipos de dados podem exigir regras de validação distintas (ex: validar um CPF vs. um CNPJ).
- **Cálculo de Preços**: Um sistema de e-commerce pode ter diferentes estratégias de precificação (desconto percentual, desconto fixo, "leve 3 pague 2", frete grátis acima de um valor).
- **Compressão de Arquivos**: Um programa pode permitir que o usuário escolha entre diferentes algoritmos de compressão (ZIP, RAR, GZIP).
- **Processamento de Pagamentos**: Diferentes métodos de pagamento (cartão de crédito, boleto, Pix) podem ser implementados como estratégias separadas.

No projeto `itau-rs4-app-entnotas-recebenotas`, o `CanalOrigemValidator` poderia ser refatorado para usar o padrão Strategy se a lógica de validação para cada canal de origem se tornasse muito complexa e distinta. Atualmente, a validação é simples (verificar se o canal existe em uma lista), então o padrão não é estritamente necessário, mas serve como um bom exemplo de onde ele poderia ser aplicado.

## 3. Vantagens

- **Princípio Aberto/Fechado**: É fácil adicionar novas estratégias sem modificar o contexto ou as estratégias existentes.
- **Redução de Condicionais**: Elimina a necessidade de `if-else` ou `switch` para selecionar o comportamento.
- **Reutilização**: Os algoritmos (estratégias) podem ser reutilizados em diferentes contextos.
- **Testabilidade**: Cada estratégia pode ser testada de forma isolada.
- **Flexibilidade**: Permite trocar o algoritmo em tempo de execução.

## 4. Desvantagens

- **Aumento do Número de Classes**: O padrão pode levar a um grande número de pequenas classes, o que pode aumentar a complexidade geral do projeto se não for bem organizado.
- **Comunicação entre Estratégia e Contexto**: O contexto pode precisar passar muitos dados para a estratégia, o que pode levar a interfaces de estratégia "gordas" ou a um acoplamento indesejado se a estratégia precisar acessar o contexto de volta.

## 5. Exemplo de Implementação em Java

### Exemplo: Sistema de Cálculo de Frete

Vamos criar um sistema que calcula o valor do frete para uma compra usando diferentes métodos de envio.

```java
// 1. Interface da Estratégia
interface EstrategiaDeFrete {
    double calcular(double pesoEmKg);
}

// 2. Implementações Concretas da Estratégia
class FreteNormal implements EstrategiaDeFrete {
    @Override
    public double calcular(double pesoEmKg) {
        // R$ 1.5 por kg
        return pesoEmKg * 1.50;
    }
}

class FreteExpresso implements EstrategiaDeFrete {
    @Override
    public double calcular(double pesoEmKg) {
        // R$ 3.0 por kg
        return pesoEmKg * 3.00;
    }
}

class FreteRetiradaLocal implements EstrategiaDeFrete {
    @Override
    public double calcular(double pesoEmKg) {
        // Grátis
        return 0;
    }
}

// 3. O Contexto que usa a Estratégia
class CalculadoraDeFrete {
    private EstrategiaDeFrete estrategia;

    // O contexto pode receber a estratégia no construtor...
    public CalculadoraDeFrete(EstrategiaDeFrete estrategia) {
        this.estrategia = estrategia;
    }

    // ...ou através de um setter, para permitir a troca em tempo de execução.
    public void setEstrategia(EstrategiaDeFrete estrategia) {
        this.estrategia = estrategia;
    }

    public double executarCalculo(double pesoEmKg) {
        if (estrategia == null) {
            throw new IllegalStateException("Nenhuma estratégia de frete foi definida.");
        }
        // O contexto delega o cálculo para o objeto de estratégia.
        return estrategia.calcular(pesoEmKg);
    }
}

// 4. Cliente
public class LojaOnline {
    public static void main(String[] args) {
        double pesoDoPedido = 5.0; // 5 kg

        // Cenário 1: Cliente escolhe frete normal
        CalculadoraDeFrete calculadora = new CalculadoraDeFrete(new FreteNormal());
        double custo = calculadora.executarCalculo(pesoDoPedido);
        System.out.printf("Custo do frete normal: R$ %.2f\n", custo); // Saída: R$ 7.50

        // Cenário 2: Cliente muda para frete expresso
        calculadora.setEstrategia(new FreteExpresso());
        custo = calculadora.executarCalculo(pesoDoPedido);
        System.out.printf("Custo do frete expresso: R$ %.2f\n", custo); // Saída: R$ 15.00

        // Cenário 3: Cliente decide retirar na loja
        calculadora.setEstrategia(new FreteRetiradaLocal());
        custo = calculadora.executarCalculo(pesoDoPedido);
        System.out.printf("Custo para retirada local: R$ %.2f\n", custo); // Saída: R$ 0.00
    }
}
```

### Aplicação com `Map` para Seleção de Estratégia (um padrão comum)

Em vez de o cliente instanciar a estratégia, podemos usar uma fábrica ou um `Map` para selecionar a estratégia com base em um parâmetro (como uma `String` ou um `Enum`).

```java
import java.util.Map;
import java.util.HashMap;

enum TipoFrete { NORMAL, EXPRESSO, RETIRADA }

class FabricaDeEstrategiaDeFrete {
    private static final Map<TipoFrete, EstrategiaDeFrete> estrategias = new HashMap<>();

    static {
        estrategias.put(TipoFrete.NORMAL, new FreteNormal());
        estrategias.put(TipoFrete.EXPRESSO, new FreteExpresso());
        estrategias.put(TipoFrete.RETIRADA, new FreteRetiradaLocal());
    }

    public static EstrategiaDeFrete obterEstrategia(TipoFrete tipo) {
        EstrategiaDeFrete estrategia = estrategias.get(tipo);
        if (estrategia == null) {
            throw new IllegalArgumentException("Tipo de frete inválido: " + tipo);
        }
        return estrategia;
    }
}

// Cliente usando a fábrica
public class LojaOnlineComFabrica {
    public static void main(String[] args) {
        double pesoDoPedido = 5.0;

        // O cliente agora só precisa saber o tipo de frete, não a classe concreta da estratégia.
        EstrategiaDeFrete estrategia = FabricaDeEstrategiaDeFrete.obterEstrategia(TipoFrete.EXPRESSO);
        CalculadoraDeFrete calculadora = new CalculadoraDeFrete(estrategia);

        double custo = calculadora.executarCalculo(pesoDoPedido);
        System.out.printf("Custo do frete expresso: R$ %.2f\n", custo); // Saída: R$ 15.00
    }
}
```
Este segundo exemplo é muito poderoso e comum em aplicações Spring, onde as estratégias (`FreteNormal`, `FreteExpresso`, etc.) seriam beans `@Component` e injetadas em um `Map` na fábrica.
