# Skills e Fontes de Conhecimento

Este arquivo serve como um índice para as habilidades, padrões e fontes de conhecimento que devem guiar o desenvolvimento deste projeto. O objetivo é criar um vocabulário e uma base de conhecimento compartilhados.

## Instrução Geral para Desenvolvimento

Durante todo o desenvolvimento deste projeto, é obrigatório aplicar as boas práticas técnicas descritas nas skills listadas abaixo, sempre que aplicável.  
Isso inclui, mas não se limita a:
 - Princípios de **Clean Code** para garantir legibilidade e manutenção.
 - Princípios **SOLID** para design flexível e sustentável.
 - Uso adequado de **Design Patterns** para resolver problemas comuns de forma reutilizável.
 - Práticas de **TDD (Test-Driven Development)** para garantir qualidade e cobertura de testes.
 - Aplicação contínua de técnicas de **Refactoring** para melhoria do código.

Essa instrução geral serve como um padrão obrigatório para todas as implementações, revisões e evoluções do código, garantindo consistência, qualidade e alinhamento com as melhores práticas do time.

## 1. Princípios de Código

- **Clean Code**:
  - **Descrição**: Práticas para escrever código legível e de fácil manutenção.
  - **Detalhes**: [Ver documento de Clean Code](./clean-code/SKILL.md)

- **SOLID**:
  - **Descrição**: Cinco princípios de design para criar software mais flexível e sustentável.
  - **Detalhes**: [Ver documento de SOLID](./solid/SKILL.md)

- **TDD (Test-Driven Development)**:
  - **Descrição**: Ciclo de desenvolvimento guiado por testes (Red-Green-Refactor).
  - **Detalhes**: [Ver documento de TDD](./tdd/SKILL.md)

## 2. Padrões de Projeto (Design Patterns)

- **Descrição**: Soluções reutilizáveis para problemas comuns de design de software.
- **Detalhes**: [Ver documento de Design Patterns](./design-patterns/SKILL.md)
- **Padrões Comuns no Projeto**:
  - **Builder**: Usado extensivamente via Lombok (`@Builder`, `@SuperBuilder`) para a criação de DTOs e objetos de domínio.
  - **Strategy**: Aplicável para variações de lógica de negócio (ex: diferentes processamentos por `canalOrigem`).
  - **Adapter**: Usado para mapear entre diferentes camadas de DTOs (ex: `S3Mapper`).

## 3. Arquitetura e Estilo

- **Arquitetura de Microsserviços**:
  - **Descrição**: Abordagem de desenvolvimento de aplicações como uma coleção de pequenos serviços independentes.
  - **Detalhes**: [Ver documento de Arquitetura de Microsserviços](./microservices-architecture/SKILL.md)

- **Arquitetura em Camadas**:
  - **Descrição**: Organização do código em camadas horizontais (Controller, Service, Repository).
  - **Detalhes**: [Ver documento de Arquitetura em Camadas](./layered-architecture/SKILL.md)

- **Observabilidade (Datadog)**:
  - **Descrição**: Padrões de logs, spans customizados (APM) e métricas custom (DogStatsD), incluindo a nomenclatura obrigatória das métricas e as regras para instrumentar novos fluxos.
  - **Detalhes**: [Ver documento de Observabilidade](./observability/SKILL.md)

- **Convenções de Código Específicas do Projeto**:
  - **Descrição**: Seguir as convenções de nomenclatura, formatação e commits descritas no guia do projeto.
  - **Detalhes**: [Ver documento de convenções](./project-specific-conventions/SKILL.md)

## 4. Tecnologias e Ferramentas

- **Java**:
  - **Descrição**: Linguagem de programação principal do projeto (versão 21).
  - **Detalhes**: [Ver documento do Java](./java/SKILL.md)
- **Spring Boot**:
  - **Descrição**: Framework para construção da aplicação.
  - **Detalhes**: [Ver documento do Spring Boot](./spring-boot/SKILL.md)
- **JUnit**:
  - **Descrição**: Framework para testes unitários.
  - **Detalhes**: [Ver documento do JUnit](./junit/SKILL.md)
- **Mockito**:
  - **Descrição**: Framework para criação de mocks em testes.
  - **Detalhes**: [Ver documento do Mockito](./mockito/SKILL.md)
- **Refactoring**:
  - **Descrição**: Técnicas para melhoria contínua do código.
  - **Detalhes**: [Ver documento de Refactoring](./refactoring/SKILL.md)
- **Terraform**:
  - **Descrição**: Ferramenta de Infraestrutura como Código para gerenciar recursos na AWS.
  - **Detalhes**: [Ver documento do Terraform](./terraform/SKILL.md)
