# Skill: Spring Boot

## 1. Descrição

Spring Boot é um framework que torna o desenvolvimento de aplicações baseadas em Spring mais rápido e fácil. Ele elimina grande parte da configuração manual necessária em projetos Spring tradicionais, permitindo que os desenvolvedores se concentrem na lógica de negócio.

Seus pilares são:
*   **Autoconfiguração**: Tenta configurar automaticamente a aplicação com base nas dependências (jars) presentes no classpath.
*   **Opinião Forte (Opinionated)**: Oferece uma visão "opinada" sobre a melhor forma de configurar e construir uma aplicação, fornecendo padrões sensatos que podem ser sobrescritos.
*   **Standalone**: Permite criar aplicações autônomas que rodam com um servidor web embarcado (como Tomcat, Jetty ou Undertow), sem a necessidade de implantar um arquivo WAR em um servidor externo.

## 2. Fontes de Conhecimento

*   **Guia de Referência Oficial**: [Spring Boot Reference Guide](https://docs.spring.io/spring-boot/docs/current/reference/html/)
*   **Guias Práticos**: [Spring.io Guides](https://spring.io/guides)

## 3. Conceitos Fundamentais

### 3.1. Inversão de Controle (IoC) e Injeção de Dependência (DI)

Este é o princípio central do Spring Framework.

*   **Inversão de Controle (IoC)**: Em vez de o seu código controlar o ciclo de vida e a criação de objetos, o controle é "invertido" e entregue ao framework (o Contêiner Spring). Sua classe não cria suas próprias dependências com `new`; ela as recebe de fora.
*   **Injeção de Dependência (DI)**: É a principal forma de implementar a IoC. O Contêiner Spring "injeta" as dependências (outros objetos) em um objeto quando ele é criado. No projeto, isso é feito principalmente via **injeção de construtor**, que é a forma recomendada.

```java
// A classe NotasServiceImpl não cria suas dependências.
// Elas são "injetadas" pelo Spring através do construtor.
@Service
@RequiredArgsConstructor // Lombok cria o construtor para nós
public class NotasServiceImpl implements NotasService {
    private final S3Repository s3Repository; // Dependência
    private final SqsService sqsService;     // Dependência
    // ...
}
```

### 3.2. Beans e o Contêiner Spring (`ApplicationContext`)

*   **Bean**: Um objeto que é instanciado, montado e gerenciado pelo Contêiner Spring. Em vez de serem simples "POJOs" (Plain Old Java Objects), os Beans são "super-objetos" que vivem dentro do contêiner e podem receber serviços do framework (como DI, gerenciamento de transações, etc.).
*   **Contêiner Spring (`ApplicationContext`)**: É o coração do Spring. Ele é responsável por criar os beans, configurá-los, conectá-los (via DI) e gerenciar seu ciclo de vida completo.

### 3.3. Escopo de Beans (Bean Scopes)

O escopo define o ciclo de vida de um bean. O padrão e mais comum é o **Singleton**.

*   **Singleton (Padrão)**: O Contêiner Spring cria **apenas uma instância** de um bean com escopo singleton para toda a aplicação. Todas as injeções desse bean apontarão para o mesmo objeto. **Todas as classes de serviço, repositório e controlador no projeto são singletons**.
*   **Outros Escopos**: Existem outros escopos para casos de uso mais específicos, como `prototype` (uma nova instância a cada injeção), `request` (uma instância por requisição HTTP), `session` (uma instância por sessão HTTP), etc.

## 4. Anotações Essenciais de Estereótipo

Spring usa anotações para detectar classes e configurá-las como beans. As anotações de estereótipo indicam o "papel" da classe na arquitetura. Todas são, no fundo, uma especialização de `@Component`.

*   `@Component`: A anotação genérica. Marca uma classe como um candidato a ser gerenciado pelo Spring. Use-a quando a classe não se encaixa em nenhuma das categorias mais específicas abaixo.
    *   **Exemplo no projeto**: `MyCustomMask` em `br.com.itau.rs4.utils` é um bom candidato para ser um `@Component`.

*   `@Service`: Marca uma classe na **camada de serviço**. Sua responsabilidade é conter a lógica de negócio e orquestrar chamadas para a camada de repositório. Semanticamente, indica que a classe cumpre um papel de serviço.
    *   **Exemplo no projeto**: `NotasServiceImpl`, `SqsServiceImpl`.

*   `@Repository`: Marca uma classe na **camada de acesso a dados (DAO)**. Além de indicar o papel da classe, esta anotação tem um benefício extra: ela habilita a tradução automática de exceções específicas da tecnologia de persistência (como `SQLException`) para a hierarquia de exceções de acesso a dados do Spring (`DataAccessException`), que são mais genéricas e não acopladas à tecnologia.
    *   **Exemplo no projeto**: `S3RepositoryImpl`.

*   `@Controller` / `@RestController`: Marca uma classe na **camada de apresentação**. É responsável por lidar com as requisições web. `@RestController` é uma conveniência que combina `@Controller` e `@ResponseBody`, indicando que os retornos dos métodos devem ser serializados diretamente no corpo da resposta (geralmente como JSON).
    *   **Exemplo no projeto**: `NotasController`.

*   `@Configuration`: Marca uma classe como uma fonte de definições de beans. Métodos dentro de uma classe `@Configuration` podem ser anotados com `@Bean` para registrar beans no contêiner Spring de forma programática.
    *   **Exemplo no projeto**: `MaskConfiguration` usa `@Configuration` para definir e registrar o bean `MyCustomMask`.

## 5. Aplicação no Projeto (Expandido)

*   **Ponto de Partida (`@SpringBootApplication`)**: A anotação `@SpringBootApplication` na classe `RecebeNotasApplication` é uma conveniência que combina três anotações:
    1.  `@EnableAutoConfiguration`: Habilita o mecanismo de autoconfiguração do Spring Boot.
    2.  `@ComponentScan`: Diz ao Spring para procurar por outros componentes, configurações e serviços no pacote da classe e subpacotes (no caso, `br.com.itau.rs4`).
    3.  `@Configuration`: Permite registrar beans extras na classe.

*   **Controladores REST**: `NotasController` usa `@RestController` e `@PostMapping` para definir endpoints HTTP. O Spring Boot mapeia automaticamente as requisições para os métodos corretos.

*   **Injeção de Dependência na Prática**: O uso de `@RequiredArgsConstructor` (Lombok) em `NotasServiceImpl` cria um construtor que recebe todas as dependências `final` (`S3Repository`, `SqsService`). O Spring Boot vê esse construtor, encontra os beans correspondentes no contêiner e os "injeta" automaticamente.

*   **Configuração Externalizada**: Os arquivos `application.properties` e `application-local.properties` são usados para definir configurações como a porta do servidor, nomes de filas SQS e buckets S3. O Spring Boot permite injetar esses valores diretamente no código usando a anotação `@Value("${nome.da.propriedade}")`.

*   **Spring Boot Actuator**: Os endpoints do Actuator (`/health`, `/info`, `/metrics`) são habilitados pela simples presença da dependência `spring-boot-starter-actuator` no `pom.xml`. Isso é um exemplo perfeito da autoconfiguração do Spring Boot.

*   **Validação de Dados**: A anotação `@Valid` no `NotasController` instrui o Spring Boot a usar o framework de Bean Validation para validar o objeto `Nota` recebido. Se a validação falhar, ele lança uma `MethodArgumentNotValidException`, que é capturada pelo `NotasExceptionHandler`.
