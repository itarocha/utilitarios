# Clean Code

## Descrição

Clean Code refere-se a um conjunto de práticas de desenvolvimento de software que visam criar código legível, compreensível e de fácil manutenção. No contexto deste projeto, adotar Clean Code é fundamental para garantir a longevidade da aplicação, facilitar a colaboração entre desenvolvedores e reduzir o custo de futuras modificações. Escrever código limpo significa escrever código que outros desenvolvedores possam entender rapidamente, modificar com segurança e expandir sem introduzir erros.

## Fontes de Conhecimento

### Artigos e Documentação

*   [Clean Code Principles Explained](https://www.freecodecamp.org/news/how-to-write-clean-code/) - Um guia abrangente sobre os princípios fundamentais do Clean Code.
*   [Writing Clean Code: Best Practices and Principles](https://dev.to/favourmark05/writing-clean-code-best-practices-and-principles-3amh) - Um artigo com exemplos práticos e dicas para escrever código mais limpo.

## Principais Pilares do Clean Code

### 1. Nomes Significativos

Nomes claros e descritivos são essenciais para a legibilidade do código. Variáveis, funções, classes e outros elementos devem ter nomes que revelem sua intenção sem necessidade de comentários adicionais. Isso facilita o entendimento imediato do propósito do código e reduz ambiguidades.

**Exemplo:**  
Em vez de usar nomes genéricos como `x` ou `data`, prefira `quantidadeDeItens` ou `processaNota`.

### 2. Funções Pequenas e Focadas

Cada função deve realizar uma única tarefa bem definida. Funções pequenas são mais fáceis de entender, testar e manter. Elas também facilitam a reutilização e a identificação de problemas.

**Exemplo:**  
Métodos como `ArquivoUtils.montarPathArquivo` e `ArquivoUtils.montarNomeExecucao` exemplificam funções focadas em uma única responsabilidade.

#### 2.1 Limite de Argumentos em Métodos e Construtores

Para manter a simplicidade, legibilidade e facilidade de manutenção, recomenda-se limitar o número de argumentos em métodos e construtores:

Máximo de 3 argumentos por método: Métodos com muitos parâmetros tendem a ser difíceis de entender e usar corretamente. Se precisar de mais dados, considere agrupar parâmetros relacionados em objetos ou usar padrões como Builder.
Máximo extremo de 5 argumentos em construtores padrão: Construtores com muitos parâmetros dificultam a criação e leitura do código. Para casos que exigem muitos parâmetros, prefira o uso do padrão Builder (ex: Lombok @Builder), que melhora a clareza e flexibilidade na criação de objetos.

### 3. Evitar Duplicação (DRY - Don't Repeat Yourself)

Duplicar código aumenta o risco de inconsistências e dificulta a manutenção. Centralizar lógicas comuns em funções ou classes utilitárias evita repetição, facilita atualizações e melhora a qualidade geral do código.

**Exemplo:**  
Classes como `ArquivoUtils` e `LogUtils` que encapsulam funcionalidades reutilizáveis.

### 4. Comentários Relevantes

Comentários devem explicar o "porquê" de decisões complexas ou não triviais, não o "o quê" o código faz — isso deve estar claro pelos nomes escolhidos. Comentários excessivos ou desnecessários podem poluir o código e dificultar a leitura.

### 5. Formatação Consistente

Manter uma formatação consistente, incluindo indentação adequada, espaçamento entre blocos e uso correto de linhas em branco, torna o código mais legível e profissional.

### 6. Tratamento de Erros Claro

Implementar tratamento de erros explícito e significativo evita falhas silenciosas, facilita a identificação de problemas e melhora a robustez da aplicação.

### 7. Testes Automatizados

Escrever testes que validem o comportamento esperado do código garante que mudanças futuras não quebrem funcionalidades existentes, promovendo confiança na evolução do sistema.

### 8. Refatoração Contínua

Revisar e melhorar o código regularmente ajuda a eliminar complexidades desnecessárias, melhorar a clareza e manter a qualidade ao longo do tempo.

### 9. Classes utilitárias

Classes utilitárias, com métodos estáticos devem sempre possuir construtor padrão privado, para evitar que sejam instanciadas.

## Aplicação no Projeto

*   **Nomes Significativos**: Utilize nomes claros e descritivos para variáveis, funções e classes, que revelem sua intenção sem necessidade de comentários adicionais. Por exemplo, nomes como `NotasController`, `processaNota` e `S3_BUCKET_RECEBE_NOTAS` facilitam o entendimento imediato do propósito do elemento.
*   **Funções Pequenas e Focadas**: Cada função deve realizar uma única tarefa bem definida. Métodos como `ArquivoUtils.montarPathArquivo` e `ArquivoUtils.montarNomeExecucao` exemplificam essa prática, tornando o código modular e fácil de testar. A função principal `NotasServiceImpl.processaNota` deve delegar responsabilidades para manter o foco e a simplicidade.
*   **Limite de Argumentos em Métodos e Construtores**: Recomenda-se limitar o número de argumentos em métodos a no máximo 3, e em construtores padrão a no máximo 5. Para casos que exigem muitos parâmetros, utilize o padrão Builder (ex: Lombok `@Builder`), que melhora a clareza e flexibilidade na criação de objetos.
*   **Evitar Duplicação (DRY - Don't Repeat Yourself)**: Centralize lógicas comuns em classes utilitárias como `ArquivoUtils` e `LogUtils`. Isso evita repetição de código, facilita a manutenção e reduz a chance de erros.
*   **Classes utilitárias**: Certifique-se de que classes utilitárias com métodos estáticos possuam um construtor padrão privado, evitando que sejam instanciadas e garantindo seu uso correto.
*   **Comentários Relevantes**: Use comentários para explicar o "porquê" de decisões complexas ou não triviais, não para descrever o que o código faz — isso deve estar claro pelos nomes escolhidos. Comentários devem agregar valor e não poluir o código.
*   **Formatação Consistente**: Mantenha uma formatação consistente para facilitar a leitura, como indentação adequada, espaçamento entre blocos de código e linhas em branco para separar conceitos.
*   **Tratamento de Erros Claro**: Implemente tratamento de erros explícito e significativo para evitar falhas silenciosas e facilitar a identificação de problemas.
*   **Testes Automatizados**: Escreva testes que validem o comportamento esperado do código, garantindo que mudanças futuras não quebrem funcionalidades existentes.
*   **Refatoração Contínua**: Revise e melhore o código regularmente para manter sua qualidade, eliminando complexidades desnecessárias e melhorando a clareza.

Adotar esses pilares no projeto contribui para um código mais robusto, sustentável e colaborativo, alinhado aos princípios do Clean Code.